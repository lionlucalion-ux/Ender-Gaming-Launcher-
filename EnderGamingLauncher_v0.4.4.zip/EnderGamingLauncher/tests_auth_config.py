import base64
import json
import unittest

from auth_config import is_public_supabase_key, is_supabase_configured, is_valid_supabase_url


def legacy_jwt(role: str, issuer: str = "supabase") -> str:
    payload = base64.urlsafe_b64encode(json.dumps({"role": role, "iss": issuer}).encode()).decode().rstrip("=")
    return f"header.{payload}.signature"


class SupabaseConfigTests(unittest.TestCase):
    def test_accepts_publishable_key(self):
        self.assertTrue(is_public_supabase_key("sb_publishable_abcdefgh12345678"))

    def test_accepts_legacy_anon_key(self):
        self.assertTrue(is_public_supabase_key(legacy_jwt("anon")))

    def test_rejects_service_role_jwt(self):
        self.assertFalse(is_public_supabase_key(legacy_jwt("service_role")))

    def test_rejects_secret_key_prefix(self):
        self.assertFalse(is_public_supabase_key("sb_secret_abcdefgh12345678"))

    def test_rejects_invalid_or_placeholder_key(self):
        for key in ("", "REPLACE_ME", "not-a-key", legacy_jwt("anon", "other")):
            with self.subTest(key=key):
                self.assertFalse(is_public_supabase_key(key))

    def test_accepts_https_supabase_project_url(self):
        self.assertTrue(is_valid_supabase_url("https://abc123.supabase.co"))

    def test_rejects_non_https_or_non_supabase_urls(self):
        for url in (
            "http://abc123.supabase.co", "https://supabase.co", 
            "https://abc123.supabase.co.evil.example", 
            "https://user@abc123.supabase.co", 
            "https://abc123.supabase.co/path", 
            "https://YOUR_PROJECT.supabase.co",
        ):
            with self.subTest(url=url):
                self.assertFalse(is_valid_supabase_url(url))

    def test_configuration_requires_both_valid_values(self):
        self.assertTrue(is_supabase_configured(
            "https://abc123.supabase.co", "sb_publishable_abcdefgh12345678"
        ))
        self.assertFalse(is_supabase_configured(
            "https://abc123.supabase.co", legacy_jwt("service_role")
        ))
        self.assertFalse(is_supabase_configured(
            "http://abc123.supabase.co", "sb_publishable_abcdefgh12345678"
        ))


if __name__ == "__main__":
    unittest.main()
