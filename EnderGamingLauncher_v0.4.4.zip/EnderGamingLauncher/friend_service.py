from __future__ import annotations

from uuid import UUID

import requests


class FriendError(Exception):
    """A safe, user-facing error from the online friend service."""


class FriendService:
    """Supabase RPC client for player search, friend requests and friend lists.

    Access tokens are requested from AuthService for each operation. This module
    never writes passwords or session tokens to files.
    """

    def __init__(self, auth_service, timeout: int = 15) -> None:
        self.auth = auth_service
        self.timeout = timeout

    @staticmethod
    def _uuid(value: str, label: str) -> str:
        try:
            return str(UUID(str(value)))
        except (ValueError, TypeError, AttributeError) as exc:
            raise FriendError(f"{label} ist ungültig.") from exc

    @staticmethod
    def _error_message(response: requests.Response) -> str:
        try:
            data = response.json()
            if isinstance(data, dict):
                message = data.get("message") or data.get("details") or data.get("hint")
                if message:
                    return str(message)[:400]
        except (ValueError, TypeError):
            pass
        if response.status_code in (401, 403):
            return "Deine Sitzung ist abgelaufen oder du hast keine Berechtigung. Bitte melde dich erneut an."
        if response.status_code == 404:
            return "Die Freundes-/Online-Status-Datenbank fehlt. Bitte führe alle SQL-Migrationen aus."
        return f"Der Freundeservice antwortet mit HTTP {response.status_code}."

    def _rpc(self, function: str, payload: dict):
        if not getattr(self.auth, "configured", False):
            raise FriendError("Supabase ist noch nicht eingerichtet. Bitte prüfe deine .env-Datei.")
        url = f"{self.auth.project_url.rstrip('/')}/rest/v1/rpc/{function}"
        try:
            headers = self.auth.get_session_headers()
            for attempt in range(2):
                response = requests.post(
                    url,
                    headers=headers,
                    json=payload,
                    timeout=self.timeout,
                    allow_redirects=False,
                )
                if response.status_code == 401 and attempt == 0:
                    restored_user = self.auth.restore_session()
                    if not restored_user:
                        raise FriendError("Deine Sitzung ist abgelaufen. Bitte melde dich erneut an.")
                    headers = self.auth.get_session_headers()
                    continue
                if not 200 <= response.status_code < 300:
                    raise FriendError(self._error_message(response))
                if response.status_code == 204:
                    return None
                try:
                    return response.json()
                except ValueError as exc:
                    raise FriendError("Supabase hat eine ungültige Antwort gesendet.") from exc
        except FriendError:
            raise
        except requests.RequestException as exc:
            raise FriendError(f"Verbindung zum Freundeservice fehlgeschlagen: {exc}") from exc
        except Exception as exc:
            message = str(exc).strip()
            raise FriendError(message or "Der Freundeservice konnte nicht erreicht werden.") from exc
        raise FriendError("Die Sitzung konnte nicht erneuert werden. Bitte melde dich erneut an.")

    @staticmethod
    def _rows(data, operation: str) -> list[dict]:
        if data is None:
            return []
        if not isinstance(data, list) or any(not isinstance(row, dict) for row in data):
            raise FriendError(f"Supabase hat eine ungültige Antwort für {operation} gesendet.")
        return data

    def search_players(self, query: str, limit: int = 10) -> list[dict]:
        needle = (query or "").strip()
        if not 3 <= len(needle) <= 32:
            raise FriendError("Die Spielersuche benötigt 3 bis 32 Zeichen.")
        if any(ord(char) < 32 or ord(char) == 127 for char in needle):
            raise FriendError("Die Suche enthält nicht erlaubte Steuerzeichen.")
        try:
            safe_limit = max(1, min(int(limit), 20))
        except (TypeError, ValueError) as exc:
            raise FriendError("Die Ergebnisanzahl ist ungültig.") from exc
        data = self._rpc("search_players", {
            "search_query": needle,
            "result_limit": safe_limit,
        })
        return self._rows(data, "Spielersuche")

    def send_friend_request(self, target_user_id: str) -> str:
        target = self._uuid(target_user_id, "Die Spieler-ID")
        data = self._rpc("send_friend_request", {"target_user_id": target})
        if isinstance(data, list) and len(data) == 1:
            data = data[0]
        if isinstance(data, dict):
            data = data.get("send_friend_request") or data.get("request_id")
        return self._uuid(data, "Die Anfrage-ID")

    def respond_to_request(self, request_id: str, accept: bool) -> bool:
        request = self._uuid(request_id, "Die Anfrage-ID")
        if not isinstance(accept, bool):
            raise FriendError("Die Antwort auf die Freundschaftsanfrage ist ungültig.")
        self._rpc("respond_friend_request", {
            "request_id": request,
            "accept_request": accept,
        })
        return True

    def cancel_request(self, request_id: str) -> bool:
        request = self._uuid(request_id, "Die Anfrage-ID")
        self._rpc("cancel_friend_request", {"request_id": request})
        return True

    def list_friends(self) -> list[dict]:
        return self._rows(self._rpc("list_friends", {}), "Freundesliste")

    def list_requests(self) -> list[dict]:
        return self._rows(self._rpc("list_friend_requests", {}), "Freundschaftsanfragen")
    def update_presence(self) -> bool:
        result = self._rpc("update_friend_presence", {})
        if result is False:
            raise FriendError("Der Online-Status konnte nicht aktualisiert werden.")
        return True

    def clear_presence(self) -> bool:
        result = self._rpc("clear_friend_presence", {})
        if result is False:
            raise FriendError("Der Online-Status konnte nicht beendet werden.")
        return True

    def list_friend_presence(self) -> list[dict]:
        return self._rows(self._rpc("list_friend_presence", {}), "Online-Status der Freunde")

