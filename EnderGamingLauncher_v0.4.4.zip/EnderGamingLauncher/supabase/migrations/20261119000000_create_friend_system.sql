-- Ender Gaming Launcher: friend search, requests and accepted friendships.
-- Run after 20261109000000_create_profiles.sql in Supabase SQL Editor.
-- The desktop app receives no direct write permission on this table. All changes
-- are made through authenticated, narrowly scoped RPC functions.

create table if not exists public.friend_requests (
    id uuid primary key default gen_random_uuid(),
    sender_id uuid not null references public.profiles (id) on delete cascade,
    receiver_id uuid not null references public.profiles (id) on delete cascade,
    status text not null default 'pending'
        check (status in ('pending', 'accepted', 'declined', 'cancelled')),
    created_at timestamptz not null default pg_catalog.now(),
    responded_at timestamptz,
    constraint friend_requests_no_self check (sender_id <> receiver_id)
);

create unique index if not exists friend_requests_one_pending_pair
on public.friend_requests (
    (least(sender_id, receiver_id)),
    (greatest(sender_id, receiver_id))
)
where status = 'pending';

create unique index if not exists friend_requests_one_accepted_pair
on public.friend_requests (
    (least(sender_id, receiver_id)),
    (greatest(sender_id, receiver_id))
)
where status = 'accepted';

create index if not exists friend_requests_sender_status_idx
on public.friend_requests (sender_id, status, created_at desc);

create index if not exists friend_requests_receiver_status_idx
on public.friend_requests (receiver_id, status, created_at desc);

alter table public.friend_requests enable row level security;
revoke all on table public.friend_requests from anon, authenticated;
grant select on table public.friend_requests to authenticated;

drop policy if exists "Users can read their own friend requests" on public.friend_requests;
create policy "Users can read their own friend requests"
on public.friend_requests
for select
to authenticated
using (
    sender_id = (select auth.uid())
    or receiver_id = (select auth.uid())
);

create or replace function public.search_players(search_query text, result_limit integer default 10)
returns table (player_id uuid, display_name text)
language plpgsql
stable
security definer
set search_path = ''
as $$
declare
    actor uuid := auth.uid();
    needle text := pg_catalog.btrim(coalesce(search_query, ''));
begin
    if actor is null then
        raise exception 'Anmeldung erforderlich.' using errcode = '28000';
    end if;
    if pg_catalog.char_length(needle) < 3 or pg_catalog.char_length(needle) > 32 then
        raise exception 'Die Spielersuche benötigt 3 bis 32 Zeichen.' using errcode = '22023';
    end if;

    return query
    select p.id, p.display_name
    from public.profiles as p
    where p.id <> actor
      and pg_catalog.left(
          pg_catalog.lower(p.display_name),
          pg_catalog.char_length(needle)
      ) = pg_catalog.lower(needle)
    order by p.display_name
    limit pg_catalog.greatest(1, pg_catalog.least(coalesce(result_limit, 10), 20));
end;
$$;

create or replace function public.send_friend_request(target_user_id uuid)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
    actor uuid := auth.uid();
    created_request_id uuid;
begin
    if actor is null then
        raise exception 'Anmeldung erforderlich.' using errcode = '28000';
    end if;
    if target_user_id is null or target_user_id = actor then
        raise exception 'Du kannst dir selbst keine Freundschaftsanfrage senden.' using errcode = '22023';
    end if;
    if not exists (select 1 from public.profiles where id = target_user_id) then
        raise exception 'Dieses Spielerprofil wurde nicht gefunden.' using errcode = 'P0002';
    end if;
    if exists (
        select 1 from public.friend_requests
        where status = 'accepted'
          and least(sender_id, receiver_id) = least(actor, target_user_id)
          and greatest(sender_id, receiver_id) = greatest(actor, target_user_id)
    ) then
        raise exception 'Ihr seid bereits befreundet.' using errcode = '23505';
    end if;
    if exists (
        select 1 from public.friend_requests
        where status = 'pending'
          and least(sender_id, receiver_id) = least(actor, target_user_id)
          and greatest(sender_id, receiver_id) = greatest(actor, target_user_id)
    ) then
        raise exception 'Zwischen euch besteht bereits eine offene Anfrage.' using errcode = '23505';
    end if;

    insert into public.friend_requests (sender_id, receiver_id)
    values (actor, target_user_id)
    returning id into created_request_id;

    return created_request_id;
exception
    when unique_violation then
        raise exception 'Zwischen euch besteht bereits eine offene Anfrage oder Freundschaft.'
            using errcode = '23505';
end;
$$;

create or replace function public.respond_friend_request(request_id uuid, accept_request boolean)
returns boolean
language plpgsql
security definer
set search_path = ''
as $$
declare
    actor uuid := auth.uid();
begin
    if actor is null then
        raise exception 'Anmeldung erforderlich.' using errcode = '28000';
    end if;
    if accept_request is null then
        raise exception 'Bitte wähle Annehmen oder Ablehnen.' using errcode = '22023';
    end if;

    update public.friend_requests
    set status = case when accept_request then 'accepted' else 'declined' end,
        responded_at = pg_catalog.now()
    where id = request_id
      and receiver_id = actor
      and status = 'pending';

    if not found then
        raise exception 'Die Anfrage ist nicht mehr offen oder gehört nicht zu deinem Konto.'
            using errcode = 'P0002';
    end if;
    return true;
end;
$$;

create or replace function public.cancel_friend_request(request_id uuid)
returns boolean
language plpgsql
security definer
set search_path = ''
as $$
declare
    actor uuid := auth.uid();
begin
    if actor is null then
        raise exception 'Anmeldung erforderlich.' using errcode = '28000';
    end if;

    update public.friend_requests
    set status = 'cancelled',
        responded_at = pg_catalog.now()
    where id = request_id
      and sender_id = actor
      and status = 'pending';

    if not found then
        raise exception 'Die Anfrage ist nicht mehr offen oder gehört nicht zu deinem Konto.'
            using errcode = 'P0002';
    end if;
    return true;
end;
$$;

create or replace function public.list_friends()
returns table (player_id uuid, display_name text, friends_since timestamptz)
language sql
stable
security definer
set search_path = ''
as $$
    select other_profile.id, other_profile.display_name, request.created_at
    from public.friend_requests as request
    join public.profiles as other_profile
      on other_profile.id = case
          when request.sender_id = (select auth.uid()) then request.receiver_id
          else request.sender_id
      end
    where request.status = 'accepted'
      and (
          request.sender_id = (select auth.uid())
          or request.receiver_id = (select auth.uid())
      )
    order by other_profile.display_name;
$$;

create or replace function public.list_friend_requests()
returns table (
    request_id uuid,
    other_user_id uuid,
    other_display_name text,
    direction text,
    created_at timestamptz
)
language sql
stable
security definer
set search_path = ''
as $$
    select
        request.id,
        other_profile.id,
        other_profile.display_name,
        case
            when request.receiver_id = (select auth.uid()) then 'incoming'
            else 'outgoing'
        end,
        request.created_at
    from public.friend_requests as request
    join public.profiles as other_profile
      on other_profile.id = case
          when request.sender_id = (select auth.uid()) then request.receiver_id
          else request.sender_id
      end
    where request.status = 'pending'
      and (
          request.sender_id = (select auth.uid())
          or request.receiver_id = (select auth.uid())
      )
    order by request.created_at desc;
$$;

revoke all on function public.search_players(text, integer) from public, anon;
revoke all on function public.send_friend_request(uuid) from public, anon;
revoke all on function public.respond_friend_request(uuid, boolean) from public, anon;
revoke all on function public.cancel_friend_request(uuid) from public, anon;
revoke all on function public.list_friends() from public, anon;
revoke all on function public.list_friend_requests() from public, anon;

grant execute on function public.search_players(text, integer) to authenticated;
grant execute on function public.send_friend_request(uuid) to authenticated;
grant execute on function public.respond_friend_request(uuid, boolean) to authenticated;
grant execute on function public.cancel_friend_request(uuid) to authenticated;
grant execute on function public.list_friends() to authenticated;
grant execute on function public.list_friend_requests() to authenticated;
