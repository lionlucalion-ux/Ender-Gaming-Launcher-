-- Ender Gaming Launcher: friend-only online presence.
-- Run after the profiles and friend-system migrations.
-- A player is online when last_seen is newer than 3 minutes.
-- Direct table access is denied; the RPCs only expose a user's own heartbeat
-- and presence of accepted friends.

create table if not exists public.friend_presence (
    user_id uuid primary key references public.profiles (id) on delete cascade,
    last_seen timestamptz not null default pg_catalog.now()
);

create index if not exists friend_presence_last_seen_idx
on public.friend_presence (last_seen desc);


alter table public.friend_presence enable row level security;
revoke all on table public.friend_presence from anon, authenticated;


create or replace function public.update_friend_presence()
returns boolean
language plpgsql
security definer
set search_path = ''
as $$
declare
    actor uuid := auth.uid();
begin
    if actor is null then
        raise exception 'Anmeldung erforderlich.' using errcode = '28000';
    end if;

    insert into public.friend_presence (user_id, last_seen)
    values (actor, pg_catalog.now())
    on conflict (user_id) do update
        set last_seen = pg_catalog.now();

    return true;
end;
$$;


create or replace function public.clear_friend_presence()
returns boolean
language plpgsql
security definer
set search_path = ''
as $$
declare
    actor uuid := auth.uid();
begin
    if actor is null then
        raise exception 'Anmeldung erforderlich.' using errcode = '28000';
    end if;

    delete from public.friend_presence where user_id = actor;
    return true;
end;
$$;


create or replace function public.list_friend_presence()
returns table (
    player_id uuid,
    display_name text,
    last_seen timestamptz,
    is_online boolean
)
language sql
stable
security definer
set search_path = ''
as $$
    select
        other_profile.id,
        other_profile.display_name,
        presence.last_seen,
        coalesce(presence.last_seen >= pg_catalog.now() - interval '3 minutes', false)
    from public.friend_requests as request
    join public.profiles as other_profile
      on other_profile.id = case
          when request.sender_id = (select auth.uid()) then request.receiver_id
          else request.sender_id
      end
    left join public.friend_presence as presence
      on presence.user_id = other_profile.id
    where request.status = 'accepted'
      and (
          request.sender_id = (select auth.uid())
          or request.receiver_id = (select auth.uid())
      )
    order by other_profile.display_name;
$$;


revoke all on function public.update_friend_presence() from public, anon;
revoke all on function public.clear_friend_presence() from public, anon;
revoke all on function public.list_friend_presence() from public, anon;
grant execute on function public.update_friend_presence() to authenticated;
grant execute on function public.clear_friend_presence() to authenticated;
grant execute on function public.list_friend_presence() to authenticated;
