-- Ender Gaming Launcher: private user profiles for Supabase Auth accounts.
-- Run this file in Supabase Dashboard -> SQL Editor.

create table if not exists public.profiles (
    id uuid primary key references auth.users (id) on delete cascade,
    display_name text not null default 'Gaming-Spieler',
    created_at timestamptz not null default now(),
    updated_at timestamptz not null default now(),
    constraint profiles_display_name_length
        check (char_length(display_name) between 3 and 32)
);

alter table public.profiles enable row level security;

-- The desktop app only needs to read and update the signed-in user's own profile.
revoke all on table public.profiles from anon, authenticated;
grant select on table public.profiles to authenticated;
grant update (display_name) on table public.profiles to authenticated;

create or replace function public.touch_enders_profile_updated_at()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
    new.updated_at := pg_catalog.now();
    return new;
end;
$$;

drop trigger if exists on_enders_profile_updated on public.profiles;
create trigger on_enders_profile_updated
before update on public.profiles
for each row execute function public.touch_enders_profile_updated_at();

drop policy if exists "Users can read their own profile" on public.profiles;
create policy "Users can read their own profile"
on public.profiles
for select
to authenticated
using ((select auth.uid()) = id);

drop policy if exists "Users can update their own profile" on public.profiles;
create policy "Users can update their own profile"
on public.profiles
for update
to authenticated
using ((select auth.uid()) = id)
with check ((select auth.uid()) = id);

-- Create a profile automatically when Supabase Auth creates a user.
create or replace function public.handle_new_enders_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
    requested_name text;
begin
    requested_name := btrim(coalesce(new.raw_user_meta_data ->> 'display_name', ''));
    if char_length(requested_name) < 3 or char_length(requested_name) > 32 then
        requested_name := 'Gaming-Spieler';
    end if;

    insert into public.profiles (id, display_name)
    values (new.id, requested_name)
    on conflict (id) do nothing;

    return new;
end;
$$;

drop trigger if exists on_enders_user_created on auth.users;
create trigger on_enders_user_created
after insert on auth.users
for each row execute function public.handle_new_enders_user();


-- Backfill profiles for accounts that existed before this migration/trigger was installed.
insert into public.profiles (id, display_name)
select
    users.id,
    case
        when pg_catalog.char_length(pg_catalog.btrim(coalesce(users.raw_user_meta_data ->> 'display_name', ''))) between 3 and 32
            then pg_catalog.btrim(users.raw_user_meta_data ->> 'display_name')
        else 'Gaming-Spieler'
    end
from auth.users as users
on conflict (id) do nothing;
