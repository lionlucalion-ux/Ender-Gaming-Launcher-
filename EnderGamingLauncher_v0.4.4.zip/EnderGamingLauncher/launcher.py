from __future__ import annotations

import base64
import hashlib
import json
import os
import re
import secrets
import subprocess
import sys
import threading
import time
import webbrowser
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlencode, urlparse
from datetime import datetime
from uuid import UUID

import requests
import keyring
from dotenv import load_dotenv
from game_detection import detect_installed_games
from game_metadata import MetadataError, download_steam_cover, fetch_steam_metadata
from game_store import GameStore
from process_monitor import match_running_processes
from auth_config import is_supabase_configured
from friend_service import FriendService, FriendError
import psutil
from PySide6.QtCore import Qt, Signal, QObject, QTimer, QThread
from PySide6.QtGui import QFont, QPixmap
from PySide6.QtWidgets import (
    QApplication, QCheckBox, QComboBox, QDialog, QFileDialog, QFrame, QHBoxLayout,
    QInputDialog, QLabel, QLineEdit, QMainWindow, QMessageBox,
    QPushButton, QScrollArea, QStackedWidget, QVBoxLayout, QGridLayout, QWidget,
    QFormLayout, QTextEdit, QDialogButtonBox,
)

APP_NAME = "Ender Gaming Launcher"
APP_VERSION = "0.4.4"
AUTH_SERVICE_NAME = "EnderGamingLauncher.Supabase"
CALLBACK_URL = "http://127.0.0.1:8765/auth/callback"

load_dotenv(Path(__file__).with_name(".env"))


class AuthError(Exception):
    pass


class AuthService:
    """Small Supabase Auth REST client. Passwords are never written to disk."""

    def __init__(self) -> None:
        self.project_url = os.getenv("SUPABASE_URL", "").strip().rstrip("/")
        # Supabase now recommends publishable keys. Keep the older anon key supported
        # so existing .env files continue to work.
        self.api_key = (
            os.getenv("SUPABASE_PUBLISHABLE_KEY", "").strip()
            or os.getenv("SUPABASE_ANON_KEY", "").strip()
        )

    @property
    def configured(self) -> bool:
        # Accept only a public publishable key or a legacy anon JWT. Secret and
        # service_role keys must never be used in a desktop client.
        return is_supabase_configured(self.project_url, self.api_key)

    def _require_config(self) -> None:
        if not self.configured:
            raise AuthError(
                "Supabase ist noch nicht eingerichtet.\n\n"
                "Öffne die Datei .env im Launcher-Ordner und trage SUPABASE_URL sowie "
                "SUPABASE_PUBLISHABLE_KEY aus deinem Supabase-Projekt ein.\n"
                "Alternativ wird auch ein älterer SUPABASE_ANON_KEY akzeptiert.\n\n"
                "Die Zugangsdaten werden nicht automatisch erstellt. Verwende niemals "
                "einen Secret- oder service_role-Key in diesem Desktop-Launcher."
            )

    def _headers(self) -> dict[str, str]:
        self._require_config()
        return {"apikey": self.api_key, "Content-Type": "application/json"}

    def get_session_headers(self) -> dict[str, str]:
        """Return API headers with the current access token from the OS credential vault."""
        self._require_config()
        try:
            access = keyring.get_password(AUTH_SERVICE_NAME, "access_token")
        except Exception as exc:
            raise AuthError(
                "Der sichere Windows-Tresor ist nicht erreichbar. Bitte melde dich erneut an."
            ) from exc
        if not access:
            raise AuthError("Du bist nicht angemeldet oder deine Sitzung ist abgelaufen.")
        return {
            **self._headers(),
            "Authorization": f"Bearer {access}",
            "Accept": "application/json",
        }

    @staticmethod
    def _message(response: requests.Response) -> str:
        try:
            data = response.json()
            return str(
                data.get("msg") or data.get("message") or data.get("error_description")
                or data.get("error") or "Unbekannter Anmeldefehler."
            )
        except Exception:
            return f"Serverantwort: HTTP {response.status_code}"

    def _post(self, endpoint: str, payload: dict) -> dict:
        self._require_config()
        try:
            response = requests.post(
                f"{self.project_url}/auth/v1/{endpoint}",
                headers=self._headers(), json=payload, timeout=20,
            )
        except requests.RequestException as exc:
            raise AuthError(f"Verbindung zu Supabase fehlgeschlagen: {exc}") from exc
        if not response.ok:
            raise AuthError(self._message(response))
        try:
            return response.json()
        except ValueError as exc:
            raise AuthError("Der Authentifizierungsserver hat eine ungültige Antwort gesendet.") from exc

    def _save_session(self, data: dict) -> dict:
        access = data.get("access_token")
        refresh = data.get("refresh_token")
        if not access or not refresh:
            raise AuthError("Anmeldung war nicht vollständig. Bitte versuche es erneut.")
        # Tokens go to the OS credential vault (Windows Credential Manager), not a plain file.
        try:
            keyring.set_password(AUTH_SERVICE_NAME, "access_token", access)
            keyring.set_password(AUTH_SERVICE_NAME, "refresh_token", refresh)
        except Exception as exc:
            raise AuthError(
                "Die Anmeldung war erfolgreich, aber der sichere Windows-Tresor ist nicht verfügbar. "
                "Installiere/aktiviere den Windows Credential Manager und versuche es erneut."
            ) from exc
        return data.get("user") or {}

    def sign_up(self, email: str, password: str, display_name: str) -> tuple[dict, bool]:
        data = self._post("signup", {
            "email": email,
            "password": password,
            "data": {"display_name": display_name},
        })
        if data.get("access_token") and data.get("refresh_token"):
            return self._save_session(data), True
        return data.get("user") or {}, False

    def sign_in(self, email: str, password: str) -> dict:
        data = self._post("token?grant_type=password", {"email": email, "password": password})
        return self._save_session(data)

    def restore_session(self) -> dict | None:
        self._require_config()
        try:
            refresh = keyring.get_password(AUTH_SERVICE_NAME, "refresh_token")
        except Exception:
            return None
        if not refresh:
            return None
        data = self._post("token?grant_type=refresh_token", {"refresh_token": refresh})
        return self._save_session(data)

    def _profile_request(self, method: str, user_id: str, display_name: str | None = None) -> dict:
        """Read/update only the signed-in user's profile; Supabase RLS is authoritative."""
        self._require_config()
        try:
            safe_user_id = str(UUID(str(user_id)))
        except (ValueError, TypeError, AttributeError) as exc:
            raise AuthError("Die Benutzer-ID ist ungültig. Bitte melde dich erneut an.") from exc

        try:
            access = keyring.get_password(AUTH_SERVICE_NAME, "access_token")
        except Exception as exc:
            raise AuthError("Der sichere Windows-Tresor ist nicht erreichbar. Bitte melde dich erneut an.") from exc
        if not access:
            raise AuthError("Deine Sitzung ist abgelaufen. Bitte melde dich erneut an.")

        endpoint = f"{self.project_url}/rest/v1/profiles"
        params = {"id": f"eq.{safe_user_id}", "select": "id,display_name,created_at,updated_at"}
        headers = {
            **self._headers(),
            "Authorization": f"Bearer {access}",
            "Accept": "application/json",
        }
        payload = {"display_name": display_name} if method == "PATCH" else None

        def send_request(current_headers: dict[str, str]) -> requests.Response:
            request_headers = dict(current_headers)
            if method == "PATCH":
                request_headers["Prefer"] = "return=representation"
            return requests.request(
                method, endpoint, headers=request_headers, params=params,
                json=payload, timeout=15,
            )

        try:
            response = send_request(headers)
            if response.status_code == 401:
                # Access tokens may expire while the launcher remains open. Refresh once.
                refreshed_user = self.restore_session()
                if not refreshed_user:
                    raise AuthError("Deine Sitzung ist abgelaufen. Bitte melde dich erneut an.")
                new_access = keyring.get_password(AUTH_SERVICE_NAME, "access_token")
                if not new_access:
                    raise AuthError("Die Sitzung konnte nicht erneuert werden. Bitte melde dich erneut an.")
                headers["Authorization"] = f"Bearer {new_access}"
                response = send_request(headers)
        except AuthError:
            raise
        except requests.RequestException as exc:
            raise AuthError(f"Das Spielerprofil konnte nicht geladen werden: {exc}") from exc
        except Exception as exc:
            raise AuthError("Der sichere Windows-Tresor konnte nicht gelesen werden. Bitte melde dich erneut an.") from exc

        if not response.ok:
            raise AuthError(self._message(response))
        try:
            rows = response.json()
        except ValueError as exc:
            raise AuthError("Supabase hat eine ungültige Profilantwort gesendet.") from exc
        if not isinstance(rows, list) or not rows:
            raise AuthError(
                "Dein Datenbankprofil wurde nicht gefunden. Bitte prüfe, ob die Datei "
                "supabase/migrations/20261109000000_create_profiles.sql im Supabase-SQL-Editor "
                "ausgeführt wurde."
            )
        return rows[0]

    def get_profile(self, user_id: str) -> dict:
        return self._profile_request("GET", user_id)

    def update_profile(self, user_id: str, display_name: str) -> dict:
        name = display_name.strip()
        if not 3 <= len(name) <= 32:
            raise AuthError("Der Anzeigename muss zwischen 3 und 32 Zeichen lang sein.")
        if any(ord(char) < 32 or ord(char) == 127 for char in name):
            raise AuthError("Der Anzeigename enthält nicht erlaubte Steuerzeichen.")
        return self._profile_request("PATCH", user_id, name)

    def sign_out(self) -> None:
        try:
            access = keyring.get_password(AUTH_SERVICE_NAME, "access_token")
            if access and self.configured:
                requests.post(
                    f"{self.project_url}/auth/v1/logout",
                    headers={**self._headers(), "Authorization": f"Bearer {access}"},
                    timeout=8,
                )
        except Exception:
            pass
        for key in ("access_token", "refresh_token"):
            try:
                keyring.delete_password(AUTH_SERVICE_NAME, key)
            except Exception:
                pass

    def start_google_login(self, callback) -> None:
        self._require_config()
        verifier = secrets.token_urlsafe(64)
        challenge = base64.urlsafe_b64encode(hashlib.sha256(verifier.encode("ascii")).digest()).decode("ascii").rstrip("=")
        state = secrets.token_urlsafe(32)

        class CallbackHandler(BaseHTTPRequestHandler):
            def do_GET(self):  # noqa: N802
                parsed = urlparse(self.path)
                params = parse_qs(parsed.query)
                if parsed.path != "/auth/callback":
                    self.send_error(404)
                    return
                returned_state = params.get("state", [""])[0]
                code = params.get("code", [""])[0]
                error = params.get("error_description", params.get("error", [""]))[0]
                if not secrets.compare_digest(returned_state, state):
                    result = {"error": "Google-Anmeldung abgebrochen: Sicherheitsprüfung fehlgeschlagen."}
                elif error:
                    result = {"error": error}
                elif not code:
                    result = {"error": "Kein Anmeldecode empfangen."}
                else:
                    try:
                        token_data = requests.post(
                            f"{service.project_url}/auth/v1/token?grant_type=pkce",
                            headers=service._headers(),
                            json={"auth_code": code, "code_verifier": verifier},
                            timeout=20,
                        )
                        if not token_data.ok:
                            raise AuthError(service._message(token_data))
                        result = {"user": service._save_session(token_data.json())}
                    except Exception as exc:
                        result = {"error": str(exc)}
                body = (
                    "<html><head><meta charset='utf-8'><title>Ender Launcher</title></head>"
                    "<body style='font-family:Arial;background:#10131c;color:white;text-align:center;padding:60px'>"
                    "<h2>Google-Anmeldung verarbeitet</h2><p>Du kannst dieses Fenster schließen und zum Launcher zurückkehren.</p>"
                    "</body></html>"
                ).encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
                callback_received.set()
                callback(result)

            def log_message(self, format, *args):
                return

        service = self
        try:
            server = HTTPServer(("127.0.0.1", 8765), CallbackHandler)
        except OSError as exc:
            raise AuthError("Der lokale Google-Login-Port 8765 ist bereits belegt. Schließe das andere Programm und versuche es erneut.") from exc
        server.timeout = 180
        callback_received = threading.Event()

        def listen_once():
            try:
                server.handle_request()
                if not callback_received.is_set():
                    callback({"error": "Google-Anmeldung ist abgelaufen. Bitte starte sie erneut."})
            finally:
                server.server_close()

        threading.Thread(target=listen_once, daemon=True).start()
        params = urlencode({
            "provider": "google",
            "redirect_to": CALLBACK_URL,
            "code_challenge": challenge,
            "code_challenge_method": "s256",
            "state": state,
        })
        auth_url = f"{self.project_url}/auth/v1/authorize?{params}"
        if not webbrowser.open(auth_url):
            raise AuthError("Der Browser konnte nicht automatisch geöffnet werden. Bitte prüfe die Windows-Standardbrowser-Einstellung.")



STYLE = """
QWidget { background:#0c1019; color:#edf2ff; font-family:'Segoe UI'; font-size:10pt; }
QFrame#Sidebar { background:#101725; border:1px solid #202b40; border-radius:18px; }
QFrame#Panel { background:#141d2d; border:1px solid #26344d; border-radius:16px; }
QFrame#GameTile { background:#141d2d; border:1px solid #293a56; border-radius:16px; }
QFrame#GameTile:hover { background:#19243a; border:1px solid #8b5cf6; }
QLabel#Muted { color:#8d9bb5; }
QLabel#Title { font-size:25pt; font-weight:800; color:#ffffff; }
QLabel#SectionTitle { font-size:16pt; font-weight:700; }
QLineEdit { background:#0d1421; border:1px solid #2b3a55; border-radius:10px; padding:12px; color:#ffffff; selection-background-color:#7c4dff; }
QLineEdit:focus { border:1px solid #8b5cf6; }
QPushButton { background:#202d43; border:1px solid #344764; border-radius:10px; padding:10px 14px; color:#eaf0ff; font-weight:600; }
QPushButton:hover { background:#2a3a56; border-color:#8b5cf6; }
QPushButton#Primary { background:#7048e8; border:1px solid #8e6cff; color:white; }
QPushButton#Primary:hover { background:#825df0; }
QPushButton#Nav { text-align:left; padding:13px 15px; background:transparent; border:0; color:#aebbd1; }
QPushButton#Nav:checked { background:#252044; color:#ffffff; border:1px solid #644bd0; }
QPushButton#Danger { background:#48232c; border-color:#713746; }
QScrollArea { border:0; }
QListWidget { background:transparent; border:0; }
QComboBox { background:#0d1421; border:1px solid #2b3a55; border-radius:10px; padding:10px; color:#ffffff; min-width:120px; }
QComboBox QAbstractItemView { background:#141d2d; color:#edf2ff; selection-background-color:#7048e8; border:1px solid #344764; }
QCheckBox { spacing:8px; color:#c8d2e5; }
"""


class AuthSignals(QObject):
    completed = Signal(dict)


class LoginPage(QWidget):
    authenticated = Signal(dict)
    continue_as_guest = Signal()

    def __init__(self, auth: AuthService):
        super().__init__()
        self.auth = auth
        self.signals = AuthSignals()
        self.signals.completed.connect(self._oauth_finished)
        self.mode = "login"
        outer = QVBoxLayout(self)
        outer.setAlignment(Qt.AlignmentFlag.AlignCenter)
        card = QFrame(objectName="Panel")
        card.setMaximumWidth(480)
        layout = QVBoxLayout(card)
        layout.setContentsMargins(34, 30, 34, 30)
        layout.setSpacing(14)

        logo = QLabel("ENDER  <span style='color:#9b7cff'>GAMING</span>")
        logo.setTextFormat(Qt.TextFormat.RichText)
        logo.setAlignment(Qt.AlignmentFlag.AlignCenter)
        logo.setFont(QFont("Segoe UI", 22, QFont.Weight.Black))
        layout.addWidget(logo)
        title = QLabel("Deine Gaming-Zentrale")
        title.setObjectName("SectionTitle")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(title)
        subtitle = QLabel("Dein Konto ist optional. Du kannst den Launcher auch ohne Anmeldung nutzen.")
        subtitle.setObjectName("Muted")
        subtitle.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(subtitle)

        tabs = QHBoxLayout()
        self.login_tab = QPushButton("Anmelden")
        self.register_tab = QPushButton("Registrieren")
        self.login_tab.setCheckable(True)
        self.register_tab.setCheckable(True)
        self.login_tab.clicked.connect(lambda: self.set_mode("login"))
        self.register_tab.clicked.connect(lambda: self.set_mode("register"))
        tabs.addWidget(self.login_tab)
        tabs.addWidget(self.register_tab)
        layout.addLayout(tabs)

        self.name = QLineEdit()
        self.name.setPlaceholderText("Anzeigename (nur bei Registrierung)")
        layout.addWidget(self.name)
        self.email = QLineEdit()
        self.email.setPlaceholderText("E-Mail-Adresse")
        self.email.setClearButtonEnabled(True)
        layout.addWidget(self.email)
        self.password = QLineEdit()
        self.password.setPlaceholderText("Passwort")
        self.password.setEchoMode(QLineEdit.EchoMode.Password)
        layout.addWidget(self.password)
        self.show_password = QCheckBox("Passwort anzeigen")
        self.show_password.toggled.connect(lambda checked: self.password.setEchoMode(QLineEdit.EchoMode.Normal if checked else QLineEdit.EchoMode.Password))
        layout.addWidget(self.show_password)

        self.submit = QPushButton("Anmelden")
        self.submit.setObjectName("Primary")
        self.submit.clicked.connect(self.submit_form)
        layout.addWidget(self.submit)
        self.google = QPushButton("Mit Google fortfahren")
        self.google.clicked.connect(self.google_login)
        layout.addWidget(self.google)
        self.guest_button = QPushButton("Ohne Anmeldung fortfahren")
        self.guest_button.clicked.connect(self.continue_as_guest.emit)
        layout.addWidget(self.guest_button)
        self.status = QLabel("Supabase-Verbindung: eingerichtet" if auth.configured else "Einrichtung erforderlich: Supabase-Zugangsdaten fehlen")
        self.status.setObjectName("Muted")
        self.status.setWordWrap(True)
        self.status.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(self.status)
        note = QLabel("Dein Passwort wird nicht lokal gespeichert. Sitzungstoken werden im sicheren Windows-Tresor abgelegt.")
        note.setObjectName("Muted")
        note.setWordWrap(True)
        note.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(note)
        outer.addWidget(card)
        self.set_mode("login")

    def set_mode(self, mode: str) -> None:
        self.mode = mode
        self.login_tab.setChecked(mode == "login")
        self.register_tab.setChecked(mode == "register")
        self.name.setVisible(mode == "register")
        self.submit.setText("Anmelden" if mode == "login" else "Konto erstellen")
        self.status.setText("Supabase-Verbindung: eingerichtet" if self.auth.configured else "Google/E-Mail-Login optional: Supabase muss zuerst eingerichtet werden.")

    def _busy(self, busy: bool) -> None:
        for widget in (self.submit, self.google, self.login_tab, self.register_tab):
            widget.setEnabled(not busy)
        self.status.setText("Bitte warten …" if busy else ("Supabase-Verbindung: eingerichtet" if self.auth.configured else "Supabase-Zugangsdaten fehlen"))

    def submit_form(self) -> None:
        email = self.email.text().strip()
        password = self.password.text()
        display_name = self.name.text().strip()
        if not re.fullmatch(r"[^\s@]+@[^\s@]+\.[^\s@]+", email):
            QMessageBox.warning(self, "E-Mail prüfen", "Bitte gib eine gültige E-Mail-Adresse ein.")
            return
        if len(password) < 8:
            QMessageBox.warning(self, "Passwort prüfen", "Das Passwort muss mindestens 8 Zeichen lang sein.")
            return
        if self.mode == "register" and not 3 <= len(display_name) <= 32:
            QMessageBox.warning(self, "Name prüfen", "Dein Anzeigename muss zwischen 3 und 32 Zeichen lang sein.")
            return
        self._busy(True)
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        try:
            if self.mode == "login":
                user = self.auth.sign_in(email, password)
                self.authenticated.emit(user)
            else:
                user, logged_in = self.auth.sign_up(email, password, display_name)
                if logged_in:
                    self.authenticated.emit(user)
                else:
                    QMessageBox.information(self, "E-Mail bestätigen", "Dein Konto wurde angelegt. Bitte bestätige zuerst den Link in deiner E-Mail und melde dich danach an.")
                    self.set_mode("login")
        except AuthError as exc:
            QMessageBox.critical(self, "Anmeldung fehlgeschlagen", str(exc))
        finally:
            QApplication.restoreOverrideCursor()
            self._busy(False)

    def google_login(self) -> None:
        self._busy(True)
        try:
            self.auth.start_google_login(lambda result: self.signals.completed.emit(result))
            self.status.setText("Google-Anmeldung läuft im Browser …")
        except AuthError as exc:
            self._busy(False)
            QMessageBox.critical(self, "Google-Anmeldung", str(exc))

    def _oauth_finished(self, result: dict) -> None:
        self._busy(False)
        if result.get("error"):
            QMessageBox.critical(self, "Google-Anmeldung fehlgeschlagen", result["error"])
        else:
            self.authenticated.emit(result.get("user") or {})


class ResizableScrollArea(QScrollArea):
    resized = Signal()

    def resizeEvent(self, event) -> None:  # noqa: N802 - Qt override
        super().resizeEvent(event)
        self.resized.emit()


class SteamMetadataWorker(QThread):
    """Fetch optional public Steam metadata without blocking the Qt interface."""

    result_ready = Signal(str, dict)
    failed = Signal(str, str)

    def __init__(self, game_id: str, app_id: str, parent=None):
        super().__init__(parent)
        self.game_id = game_id
        self.app_id = app_id

    def run(self) -> None:
        try:
            metadata = fetch_steam_metadata(self.app_id)
            try:
                cover_path = download_steam_cover(
                    self.app_id, metadata.get("header_image_url", "")
                )
            except OSError:
                # Metadata is still useful even when the local cover cache is unavailable.
                cover_path = ""
            if cover_path:
                metadata["downloaded_cover_path"] = cover_path
            self.result_ready.emit(self.game_id, metadata)
        except MetadataError as exc:
            self.failed.emit(self.game_id, str(exc))
        except Exception as exc:  # keep unexpected provider failures out of the GUI thread
            self.failed.emit(self.game_id, f"Die Spieldaten konnten nicht verarbeitet werden: {exc}")


class GameLibraryPage(QWidget):
    def __init__(self, store: GameStore):
        super().__init__()
        self.store = store
        self._active_game_sessions: dict[str, float] = {}
        self._active_game_names: list[str] = []
        self._metadata_workers: dict[str, SteamMetadataWorker] = {}
        self._metadata_status_labels: dict[str, QLabel] = {}
        app = QApplication.instance()
        if app is not None:
            app.aboutToQuit.connect(self._wait_metadata_workers)
        self._playtime_timer = QTimer(self)
        self._playtime_timer.setInterval(15000)
        self._playtime_timer.timeout.connect(self._poll_game_processes)
        self._playtime_timer.start()
        root = QVBoxLayout(self)
        header = QHBoxLayout()
        title = QLabel("Spielebibliothek")
        title.setObjectName("Title")
        header.addWidget(title)
        header.addStretch()
        self.running_status = QLabel("● Kein Spiel aktiv")
        self.running_status.setStyleSheet("color:#8d9bb2;font-size:9pt;padding-right:10px")
        header.addWidget(self.running_status)
        self.scan_button = QPushButton("⌕ Installierte Spiele erkennen")
        self.scan_button.setToolTip("Sucht in Steam-, Epic-, Xbox-, GOG- und EA-Installationsdaten")
        self.scan_button.clicked.connect(self.scan_installed_games)
        header.addWidget(self.scan_button)
        self.add_button = QPushButton("＋ Spiel hinzufügen")
        self.add_button.setObjectName("Primary")
        self.add_button.clicked.connect(self.add_game)
        header.addWidget(self.add_button)
        root.addLayout(header)

        controls = QHBoxLayout()
        self.search = QLineEdit()
        self.search.setPlaceholderText("Spiele, Kategorien oder Plattformen suchen …")
        self.search.textChanged.connect(self.refresh)
        controls.addWidget(self.search, 2)

        self.filter_combo = QComboBox()
        self.filter_combo.setMinimumWidth(170)
        self.filter_combo.currentIndexChanged.connect(self.refresh)
        controls.addWidget(self.filter_combo)

        self.sort_combo = QComboBox()
        self.sort_combo.addItem("Name: A–Z", "name")
        self.sort_combo.addItem("Zuletzt gespielt", "played")
        self.sort_combo.addItem("Zuletzt hinzugefügt", "added")
        self.sort_combo.currentIndexChanged.connect(self.refresh)
        controls.addWidget(self.sort_combo)

        self.view_combo = QComboBox()
        self.view_combo.addItem("Listenansicht", "list")
        self.view_combo.addItem("Kachelansicht", "grid")
        self.view_combo.setToolTip("Darstellung der Spielebibliothek auswählen")
        self.view_combo.currentIndexChanged.connect(self.refresh)
        controls.addWidget(self.view_combo)
        root.addLayout(controls)

        self.summary = QLabel()
        self.summary.setObjectName("Muted")
        root.addWidget(self.summary)

        self.view_stack = QStackedWidget()

        self.list_area = QScrollArea()
        self.list_area.setWidgetResizable(True)
        self.list_content = QWidget()
        self.cards = QVBoxLayout(self.list_content)
        self.cards.setAlignment(Qt.AlignmentFlag.AlignTop)
        self.list_area.setWidget(self.list_content)
        self.view_stack.addWidget(self.list_area)

        self.grid_area = ResizableScrollArea()
        self.grid_area.setWidgetResizable(True)
        self.grid_area.resized.connect(self._update_grid_columns)
        self.grid_content = QWidget()
        self.grid_cards = QGridLayout(self.grid_content)
        self.grid_cards.setAlignment(Qt.AlignmentFlag.AlignTop | Qt.AlignmentFlag.AlignLeft)
        self.grid_cards.setContentsMargins(4, 4, 4, 4)
        self.grid_cards.setHorizontalSpacing(14)
        self.grid_cards.setVerticalSpacing(14)
        self.grid_area.setWidget(self.grid_content)
        self.view_stack.addWidget(self.grid_area)
        self._grid_columns = 0
        root.addWidget(self.view_stack, 1)
        self.refresh()

    def add_game(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "Spiel auswählen", str(Path.home()), "Programme (*.exe *.lnk)")
        if not path:
            return
        try:
            self.store.add(path)
            self.refresh()
        except ValueError as exc:
            QMessageBox.information(self, "Spiel bereits vorhanden", str(exc))

    def scan_installed_games(self) -> None:
        self.scan_button.setEnabled(False)
        self.scan_button.setText("Suche läuft …")
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        try:
            detected = detect_installed_games()
            added = sum(1 for game in detected if self.store.add_detected(game))
            self.refresh()
            if detected:
                QMessageBox.information(
                    self, "Spieleerkennung abgeschlossen",
                    f"Gefunden: {len(detected)}\nNeu zur Bibliothek hinzugefügt: {added}\nBereits vorhanden: {len(detected) - added}\n\nUnterstützt werden Steam, Epic Games, Xbox, GOG und EA app.",
                )
            else:
                QMessageBox.information(
                    self, "Keine Spiele gefunden",
                    "In den bekannten Installationsdaten von Steam, Epic Games, Xbox, GOG und EA app wurden keine installierten Spiele gefunden.\n\nDu kannst Spiele weiterhin über „Spiel hinzufügen“ manuell eintragen.",
                )
        except Exception as exc:
            QMessageBox.warning(self, "Spieleerkennung fehlgeschlagen", f"Die Installationsdaten konnten nicht gelesen werden: {exc}")
        finally:
            QApplication.restoreOverrideCursor()
            self.scan_button.setEnabled(True)
            self.scan_button.setText("⌕ Installierte Spiele erkennen")

    def _refresh_filter_options(self) -> None:
        current = self.filter_combo.currentData()
        categories = sorted(
            {str(game.get("category") or "Nicht kategorisiert") for game in self.store.games},
            key=str.casefold,
        )
        self.filter_combo.blockSignals(True)
        self.filter_combo.clear()
        self.filter_combo.addItem("Alle Spiele", "__all__")
        self.filter_combo.addItem("★ Nur Favoriten", "__favorites__")
        for category in categories:
            self.filter_combo.addItem(f"Kategorie: {category}", f"category:{category}")
        index = self.filter_combo.findData(current)
        self.filter_combo.setCurrentIndex(index if index >= 0 else 0)
        self.filter_combo.blockSignals(False)

    @staticmethod
    def _format_played(value: str) -> str:
        if not value:
            return "Noch nie gestartet"
        try:
            moment = datetime.fromisoformat(value.replace("Z", "+00:00"))
            return moment.astimezone().strftime("%d.%m.%Y, %H:%M Uhr")
        except (TypeError, ValueError):
            return "Zeitpunkt unbekannt"

    def _clear_layout(self, layout) -> None:
        while layout.count():
            item = layout.takeAt(0)
            widget = item.widget()
            if widget is not None:
                widget.deleteLater()

    def _update_grid_columns(self) -> None:
        if not hasattr(self, "grid_area"):
            return
        width = max(1, self.grid_area.viewport().width())
        columns = max(1, min(4, (width - 24) // 250))
        if columns != self._grid_columns:
            self._grid_columns = columns
            if self.view_combo.currentData() == "grid":
                self.refresh()

    def refresh(self) -> None:
        self._clear_layout(self.cards)
        self._clear_layout(self.grid_cards)
        self._refresh_filter_options()
        query = self.search.text().strip().casefold() if hasattr(self, "search") else ""
        selected_filter = self.filter_combo.currentData() if hasattr(self, "filter_combo") else "__all__"
        games = list(self.store.games)
        if query:
            games = [
                game for game in games
                if query in str(game.get("name", "")).casefold()
                or query in str(game.get("category", "")).casefold()
                or query in str(game.get("source", "")).casefold()
            ]
        if selected_filter == "__favorites__":
            games = [game for game in games if bool(game.get("favorite"))]
        elif isinstance(selected_filter, str) and selected_filter.startswith("category:"):
            category = selected_filter.split(":", 1)[1]
            games = [game for game in games if str(game.get("category") or "Nicht kategorisiert") == category]

        sort_mode = self.sort_combo.currentData() if hasattr(self, "sort_combo") else "name"
        if sort_mode == "played":
            games.sort(key=lambda game: str(game.get("last_played_at") or ""), reverse=True)
        elif sort_mode == "added":
            games.sort(key=lambda game: str(game.get("added_at") or ""), reverse=True)
        else:
            games.sort(key=lambda game: str(game.get("name", "")).casefold())

        self.summary.setText(f"{len(games)} von {len(self.store.games)} Spielen angezeigt")
        is_grid = self.view_combo.currentData() == "grid"
        self.view_stack.setCurrentIndex(1 if is_grid else 0)
        if not games:
            empty = QLabel(
                "Keine passenden Spiele gefunden. Passe Suche oder Filter an oder füge ein Spiel hinzu."
            )
            empty.setObjectName("Muted")
            empty.setWordWrap(True)
            if is_grid:
                self.grid_cards.addWidget(empty, 0, 0)
            else:
                self.cards.addWidget(empty)
            return

        if is_grid:
            if self._grid_columns < 1:
                width = max(1, self.grid_area.viewport().width())
                self._grid_columns = max(1, min(4, (width - 24) // 250))
            columns = max(1, self._grid_columns)
            for index, game in enumerate(games):
                self.grid_cards.addWidget(self._game_tile(game), index // columns, index % columns)
            for column in range(columns):
                self.grid_cards.setColumnStretch(column, 1)
        else:
            for game in games:
                self.cards.addWidget(self._game_card(game))
        self.cards.addStretch() if not is_grid else None

    @staticmethod
    def _show_cover(label: QLabel, cover_path: str, fallback: str = "▶") -> None:
        label.setPixmap(QPixmap())
        label.setText(fallback)
        label.setStyleSheet(
            "background:#28204b;border:1px solid #3b3264;border-radius:12px;"
            "color:#b8a5ff;font-size:22pt;font-weight:800"
        )
        if not cover_path:
            return
        image_path = Path(cover_path)
        if not image_path.is_file():
            return
        pixmap = QPixmap(str(image_path))
        if pixmap.isNull():
            return
        label.setText("")
        label.setStyleSheet("background:#101725;border:1px solid #344764;border-radius:12px")
        label.setPixmap(
            pixmap.scaled(
                label.size(), Qt.AspectRatioMode.KeepAspectRatio,
                Qt.TransformationMode.SmoothTransformation,
            )
        )

    def _game_card(self, game: dict) -> QWidget:
        card = QFrame(objectName="Panel")
        row = QHBoxLayout(card)
        tile = QLabel()
        tile.setAlignment(Qt.AlignmentFlag.AlignCenter)
        tile.setFixedSize(76, 100)
        self._show_cover(tile, str(game.get("cover_path") or ""))
        row.addWidget(tile)
        details = QVBoxLayout()
        name = QLabel(game.get("name", "Unbekanntes Spiel"))
        name.setStyleSheet("font-size:12pt;font-weight:700")
        details.addWidget(name)
        metadata = QLabel(
            f"{game.get('source', 'Manuell')}  •  Kategorie: {game.get('category') or 'Nicht kategorisiert'}"
            f"  •  Zuletzt gespielt: {self._format_played(str(game.get('last_played_at') or ''))}"
        )
        metadata.setObjectName("Muted")
        metadata.setWordWrap(True)
        details.addWidget(metadata)
        path = QLabel(game.get("path", ""))
        path.setObjectName("Muted")
        path.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        path.setWordWrap(True)
        details.addWidget(path)
        row.addLayout(details, 1)

        detail_button = QPushButton("Details / Cover")
        detail_button.setToolTip("Spieldetails ansehen und Cover verwalten")
        detail_button.clicked.connect(lambda _=False, g=game: self._open_game_details(g))
        row.addWidget(detail_button)

        favorite = QPushButton("★" if game.get("favorite") else "☆")
        favorite.setToolTip("Favorit umschalten")
        favorite.clicked.connect(lambda _=False, gid=game["id"]: self._favorite(gid))
        row.addWidget(favorite)
        play = QPushButton("Starten")
        play.setObjectName("Primary")
        play.clicked.connect(lambda _=False, g=game: self.launch_game(g))
        row.addWidget(play)
        remove = QPushButton("Entfernen")
        remove.clicked.connect(lambda _=False, gid=game["id"]: self._remove(gid))
        row.addWidget(remove)
        return card

    def _game_tile(self, game: dict) -> QWidget:
        card = QFrame(objectName="GameTile")
        card.setFixedWidth(232)
        card.setStyleSheet(
            "QFrame#GameTile { background:#141d2d; border:1px solid #293a56; border-radius:16px; }"
            "QFrame#GameTile:hover { background:#19243a; border:1px solid #8b5cf6; }"
        )
        box = QVBoxLayout(card)
        box.setContentsMargins(10, 10, 10, 10)
        box.setSpacing(8)

        cover = QLabel()
        cover.setAlignment(Qt.AlignmentFlag.AlignCenter)
        cover.setFixedSize(210, 118)
        self._show_cover(cover, str(game.get("cover_path") or ""), "ENDER")
        box.addWidget(cover, 0, Qt.AlignmentFlag.AlignHCenter)

        name = QLabel(str(game.get("name") or "Unbekanntes Spiel"))
        name.setStyleSheet("font-size:11pt;font-weight:800;color:#ffffff;background:transparent;border:0")
        name.setWordWrap(True)
        name.setMinimumHeight(38)
        name.setMaximumHeight(44)
        box.addWidget(name)

        meta = QLabel(
            f"{game.get('source') or 'Manuell'}  •  {game.get('category') or 'Nicht kategorisiert'}"
        )
        meta.setObjectName("Muted")
        meta.setStyleSheet("background:transparent;border:0")
        meta.setWordWrap(True)
        meta.setMaximumHeight(34)
        box.addWidget(meta)

        actions = QHBoxLayout()
        details = QPushButton("Details")
        details.clicked.connect(lambda _=False, selected=game: self._open_game_details(selected))
        favorite = QPushButton("★" if game.get("favorite") else "☆")
        favorite.setFixedWidth(42)
        favorite.setToolTip("Favorit umschalten")
        favorite.clicked.connect(lambda _=False, gid=game["id"]: self._favorite(gid))
        play = QPushButton("▶")
        play.setObjectName("Primary")
        play.setToolTip("Spiel starten")
        play.clicked.connect(lambda _=False, selected=game: self.launch_game(selected))
        actions.addWidget(details, 1)
        actions.addWidget(favorite)
        actions.addWidget(play)
        box.addLayout(actions)
        return card

    @staticmethod
    def _format_playtime(seconds: object) -> str:
        try:
            total = max(0, int(seconds or 0))
        except (TypeError, ValueError):
            total = 0
        hours, remainder = divmod(total, 3600)
        minutes = remainder // 60
        return f"{hours} Std. {minutes} Min." if hours else f"{minutes} Min."

    def _open_game_details(self, game: dict) -> None:
        dialog = QDialog(self)
        dialog.setWindowTitle(f"{game.get('name', 'Spiel')} – Spieldetails")
        dialog.setMinimumSize(780, 760)
        layout = QVBoxLayout(dialog)
        heading = QLabel(str(game.get("name", "Unbekanntes Spiel")))
        heading.setObjectName("Title")
        layout.addWidget(heading)
        metadata_title = str(game.get("metadata_title") or "").strip()
        if metadata_title and metadata_title.casefold() != str(game.get("name") or "").casefold():
            alternate_title = QLabel(f"Steam-Titel: {metadata_title}")
            alternate_title.setObjectName("Muted")
            layout.addWidget(alternate_title)

        banner = QLabel()
        banner.setFixedSize(700, 145)
        banner.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._show_background(banner, str(game.get("background_path") or ""))
        layout.addWidget(banner)

        content = QHBoxLayout()
        cover = QLabel()
        cover.setFixedSize(170, 225)
        cover.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._show_cover(cover, str(game.get("cover_path") or ""), "KEIN\nCOVER")
        content.addWidget(cover)

        info = QVBoxLayout()
        category_value_label = None
        for caption, value in (
            ("PLATTFORM", str(game.get("source") or "Manuell")),
            ("KATEGORIE", str(game.get("category") or "Nicht kategorisiert")),
            ("INSTALLATIONSPFAD", str(game.get("path") or "Nicht hinterlegt")),
            ("LETZTER START", self._format_played(str(game.get("last_played_at") or ""))),
            ("GESAMTSPIELZEIT", self._format_playtime(game.get("playtime_seconds", 0))),
        ):
            label = QLabel(caption)
            label.setObjectName("Muted")
            value_label = QLabel(value)
            value_label.setWordWrap(True)
            value_label.setTextFormat(Qt.TextFormat.PlainText)
            value_label.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
            if caption == "KATEGORIE":
                category_value_label = value_label
            info.addWidget(label)
            info.addWidget(value_label)
            info.addSpacing(7)
        info.addStretch()
        content.addLayout(info, 1)
        layout.addLayout(content)

        metadata_frame = QFrame()
        metadata_frame.setStyleSheet("QFrame { background:#111a2a; border:1px solid #2d3d58; border-radius:10px; }")
        metadata_layout = QFormLayout(metadata_frame)
        metadata_layout.setContentsMargins(12, 10, 12, 10)
        metadata_layout.setHorizontalSpacing(16)
        metadata_layout.setVerticalSpacing(6)
        metadata_value_labels: dict[str, QLabel] = {}
        for key, caption in (
            ("developer", "Entwickler"),
            ("publisher", "Publisher"),
            ("release_date", "Erscheinungsdatum"),
            ("genres", "Genres"),
            ("description", "Beschreibung"),
            ("website", "Website"),
        ):
            value_label = QLabel()
            value_label.setWordWrap(True)
            value_label.setTextFormat(Qt.TextFormat.PlainText)
            value_label.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
            if key == "description":
                value_label.setMaximumHeight(72)
            metadata_value_labels[key] = value_label
            metadata_layout.addRow(caption, value_label)

        def refresh_metadata_labels() -> None:
            for key, value_label in metadata_value_labels.items():
                value = game.get(key, "")
                if key == "genres" and isinstance(value, list):
                    value = ", ".join(str(item) for item in value)
                value_label.setText(str(value or "Noch keine Angaben"))

        refresh_metadata_labels()
        layout.addWidget(metadata_frame)
        metadata_source = QLabel(
            f"Datenquelle: {game.get('metadata_source') or 'Noch nicht hinterlegt'}"
            + (f" · Aktualisiert: {game.get('metadata_updated_at')}" if game.get("metadata_updated_at") else "")
        )
        metadata_source.setObjectName("Muted")
        layout.addWidget(metadata_source)
        metadata_status = QLabel("")
        metadata_status.setObjectName("Muted")
        metadata_status.setWordWrap(True)
        layout.addWidget(metadata_status)

        metadata_actions = QHBoxLayout()
        app_id = str(game.get("app_id") or "").strip()
        if not app_id:
            match = re.fullmatch(r"steam://rungameid/([0-9]{1,12})", str(game.get("launch_target") or "").strip(), re.IGNORECASE)
            app_id = match.group(1) if match else ""
        if not re.fullmatch(r"[0-9]{1,12}", app_id):
            app_id = ""
        fetch_metadata_button = QPushButton("Steam-Infos + Cover laden")
        fetch_metadata_button.setEnabled(bool(app_id))
        fetch_metadata_button.setToolTip(
            "Öffentliche Spieldaten aus dem Steam Store abrufen" if app_id
            else "Automatische Metadaten sind derzeit für erkannte Steam-Spiele verfügbar"
        )
        edit_metadata_button = QPushButton("Infos bearbeiten")
        metadata_actions.addWidget(fetch_metadata_button)
        metadata_actions.addWidget(edit_metadata_button)
        metadata_actions.addStretch()
        layout.addLayout(metadata_actions)

        image_actions = QHBoxLayout()
        choose_cover = QPushButton("Cover auswählen")
        clear_cover = QPushButton("Cover entfernen")
        clear_cover.setEnabled(bool(game.get("cover_path")))
        choose_background = QPushButton("Hintergrund auswählen")
        clear_background = QPushButton("Hintergrund entfernen")
        clear_background.setEnabled(bool(game.get("background_path")))
        for button in (choose_cover, clear_cover, choose_background, clear_background):
            image_actions.addWidget(button)
        layout.addLayout(image_actions)

        footer_actions = QHBoxLayout()
        category_button = QPushButton("Kategorie ändern")
        close_button = QPushButton("Schließen")
        close_button.setObjectName("Primary")
        footer_actions.addWidget(category_button)
        footer_actions.addStretch()
        footer_actions.addWidget(close_button)
        layout.addLayout(footer_actions)

        def choose_image(is_background: bool) -> None:
            selected, _ = QFileDialog.getOpenFileName(
                dialog, "Hintergrundbild auswählen" if is_background else "Spielcover auswählen",
                str(Path.home()), "Bilder (*.png *.jpg *.jpeg *.webp *.bmp *.gif)",
            )
            if not selected:
                return
            try:
                if is_background:
                    self.store.set_background_path(str(game["id"]), selected)
                    game["background_path"] = str(Path(selected).resolve())
                    self._show_background(banner, game["background_path"])
                    clear_background.setEnabled(True)
                else:
                    self.store.set_cover_path(str(game["id"]), selected)
                    game["cover_path"] = str(Path(selected).resolve())
                    self._show_cover(cover, game["cover_path"], "KEIN\nCOVER")
                    clear_cover.setEnabled(True)
                self.refresh()
            except ValueError as exc:
                QMessageBox.warning(dialog, "Bild konnte nicht gespeichert werden", str(exc))

        def clear_image(is_background: bool) -> None:
            try:
                if is_background:
                    self.store.clear_background_path(str(game["id"]))
                    game["background_path"] = ""
                    self._show_background(banner, "")
                    clear_background.setEnabled(False)
                else:
                    self.store.clear_cover_path(str(game["id"]))
                    game["cover_path"] = ""
                    self._show_cover(cover, "", "KEIN\nCOVER")
                    clear_cover.setEnabled(False)
                self.refresh()
            except ValueError as exc:
                QMessageBox.warning(dialog, "Bild konnte nicht entfernt werden", str(exc))

        def edit_metadata() -> None:
            editor = QDialog(dialog)
            editor.setWindowTitle("Spielinformationen bearbeiten")
            editor.setMinimumWidth(520)
            form = QFormLayout(editor)
            title_input = QLineEdit(str(game.get("metadata_title") or ""))
            developer_input = QLineEdit(str(game.get("developer") or ""))
            publisher_input = QLineEdit(str(game.get("publisher") or ""))
            release_input = QLineEdit(str(game.get("release_date") or ""))
            genres_value = game.get("genres", [])
            genres_input = QLineEdit(", ".join(genres_value) if isinstance(genres_value, list) else str(genres_value or ""))
            website_input = QLineEdit(str(game.get("website") or ""))
            description_input = QTextEdit()
            description_input.setPlainText(str(game.get("description") or ""))
            description_input.setMaximumHeight(130)
            form.addRow("Angezeigter Titel", title_input)
            form.addRow("Entwickler", developer_input)
            form.addRow("Publisher", publisher_input)
            form.addRow("Erscheinungsdatum", release_input)
            form.addRow("Genres (mit Komma trennen)", genres_input)
            form.addRow("Website", website_input)
            form.addRow("Beschreibung", description_input)
            buttons = QDialogButtonBox(
                QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel
            )
            buttons.accepted.connect(editor.accept)
            buttons.rejected.connect(editor.reject)
            form.addRow(buttons)
            if editor.exec() != QDialog.DialogCode.Accepted:
                return
            values = {
                "metadata_title": title_input.text(),
                "developer": developer_input.text(),
                "publisher": publisher_input.text(),
                "release_date": release_input.text(),
                "genres": genres_input.text(),
                "website": website_input.text(),
                "description": description_input.toPlainText(),
                "metadata_source": "Manuell bearbeitet",
            }
            try:
                self.store.set_metadata(str(game["id"]), values)
                game.update(values)
                game["genres"] = [part.strip() for part in genres_input.text().split(",") if part.strip()][:12]
                refresh_metadata_labels()
                metadata_source.setText("Datenquelle: Manuell bearbeitet")
                self.refresh()
            except ValueError as exc:
                QMessageBox.warning(editor, "Ungültige Spieldaten", str(exc))

        def fetch_metadata() -> None:
            metadata_status.setText("Steam-Spieldaten werden im Hintergrund geladen. Die Oberfläche bleibt bedienbar.")
            self._metadata_status_labels[str(game.get("id") or "")] = metadata_status
            self._start_steam_metadata(game)

        def edit_category() -> None:
            self._edit_category(game)
            if category_value_label is not None:
                category_value_label.setText(str(game.get("category") or "Nicht kategorisiert"))

        choose_cover.clicked.connect(lambda: choose_image(False))
        clear_cover.clicked.connect(lambda: clear_image(False))
        choose_background.clicked.connect(lambda: choose_image(True))
        clear_background.clicked.connect(lambda: clear_image(True))
        category_button.clicked.connect(edit_category)
        edit_metadata_button.clicked.connect(edit_metadata)
        fetch_metadata_button.clicked.connect(fetch_metadata)
        close_button.clicked.connect(dialog.accept)
        dialog.exec()

    def _start_steam_metadata(self, game: dict) -> None:
        game_id = str(game.get("id") or "")
        app_id = str(game.get("app_id") or "").strip()
        if not app_id:
            match = re.fullmatch(r"steam://rungameid/([0-9]{1,12})", str(game.get("launch_target") or "").strip(), re.IGNORECASE)
            app_id = match.group(1) if match else ""
        if not app_id:
            QMessageBox.information(self, "Steam-Metadaten", "Für dieses Spiel wurde keine Steam-App-ID gefunden.")
            return
        existing = self._metadata_workers.get(game_id)
        if existing is not None and existing.isRunning():
            QMessageBox.information(self, "Steam-Metadaten", "Für dieses Spiel werden bereits Daten geladen.")
            return
        worker = SteamMetadataWorker(game_id, app_id, self)
        worker.result_ready.connect(self._on_steam_metadata_loaded)
        worker.failed.connect(self._on_steam_metadata_failed)
        worker.finished.connect(lambda current_id=game_id: self._metadata_workers.pop(current_id, None))
        self._metadata_workers[game_id] = worker
        worker.start()

    def _wait_metadata_workers(self) -> None:
        for worker in list(self._metadata_workers.values()):
            if worker.isRunning():
                worker.wait(28000)

    def _on_steam_metadata_loaded(self, game_id: str, metadata: dict) -> None:
        values = dict(metadata)
        downloaded_cover = str(values.pop("downloaded_cover_path", "") or "")
        try:
            self.store.set_metadata(game_id, values)
            if downloaded_cover:
                self.store.set_cover_path(game_id, downloaded_cover)
            self.refresh()
            status_label = self._metadata_status_labels.pop(game_id, None)
            if status_label is not None:
                try:
                    status_label.setText("Steam-Daten gespeichert. Spieldetails zum Aktualisieren erneut öffnen.")
                except RuntimeError:
                    pass
            detail = "Spieldaten wurden gespeichert."
            if downloaded_cover:
                detail += " Das Cover wurde ebenfalls heruntergeladen."
            else:
                detail += " Für dieses Spiel war kein automatisches Cover verfügbar; du kannst ein eigenes auswählen."
            QMessageBox.information(self, "Steam-Daten geladen", detail + " Öffne die Spieldetails erneut, um die Angaben zu sehen.")
        except ValueError as exc:
            QMessageBox.warning(self, "Spieldaten konnten nicht gespeichert werden", str(exc))

    def _on_steam_metadata_failed(self, game_id: str, message: str) -> None:
        status_label = self._metadata_status_labels.pop(game_id, None)
        if status_label is not None:
            try:
                status_label.setText(message)
            except RuntimeError:
                pass
        QMessageBox.warning(self, "Steam-Metadaten", message)

    @staticmethod
    def _show_background(label: QLabel, background_path: str) -> None:
        label.setPixmap(QPixmap())
        label.setText("SPIEL-HINTERGRUND")
        label.setStyleSheet(
            "background:#1b2440;border:1px solid #3b4c70;border-radius:14px;"
            "color:#aebbd1;font-size:14pt;font-weight:800"
        )
        if not background_path:
            return
        image_path = Path(background_path)
        if not image_path.is_file():
            return
        pixmap = QPixmap(str(image_path))
        if pixmap.isNull():
            return
        target = label.size()
        if target.width() <= 0 or target.height() <= 0:
            return
        scaled = pixmap.scaled(
            target, Qt.AspectRatioMode.KeepAspectRatioByExpanding,
            Qt.TransformationMode.SmoothTransformation,
        )
        x = max(0, (scaled.width() - target.width()) // 2)
        y = max(0, (scaled.height() - target.height()) // 2)
        label.setText("")
        label.setStyleSheet("background:#101725;border:1px solid #344764;border-radius:14px")
        label.setPixmap(scaled.copy(x, y, target.width(), target.height()))

    def _edit_category(self, game: dict) -> None:
        current = str(game.get("category") or "Nicht kategorisiert")
        category, accepted = QInputDialog.getText(
            self, "Spielkategorie ändern", "Kategorie (maximal 32 Zeichen):",
            QLineEdit.EchoMode.Normal, current,
        )
        if not accepted:
            return
        try:
            self.store.set_category(str(game["id"]), category)
            self.refresh()
        except ValueError as exc:
            QMessageBox.information(self, "Ungültige Kategorie", str(exc))

    def _favorite(self, game_id: str) -> None:
        self.store.toggle_favorite(game_id)
        self.refresh()

    def _remove(self, game_id: str) -> None:
        self.store.remove(game_id)
        self.refresh()

    def _poll_game_processes(self) -> None:
        """Detect running games by executable path and account elapsed playtime."""
        snapshots: list[tuple[int, str]] = []
        try:
            for process in psutil.process_iter(("pid", "exe")):
                try:
                    info = process.info
                    executable = str(info.get("exe") or "")
                    if executable:
                        snapshots.append((int(info["pid"]), executable))
                except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess, KeyError, TypeError):
                    continue
        except Exception:
            # Process monitoring must never make the library unusable.
            return

        matches = match_running_processes(self.store.games, snapshots)
        now = time.monotonic()
        active_names: list[str] = []
        active_ids = set(matches)
        for game_id in active_ids:
            game = next((item for item in self.store.games if str(item.get("id")) == game_id), None)
            if game is None:
                continue
            active_names.append(str(game.get("name") or "Spiel"))
            previous = self._active_game_sessions.get(game_id)
            if previous is not None:
                elapsed = max(0, min(int(now - previous), 90))
                if elapsed:
                    try:
                        self.store.add_playtime(game_id, elapsed)
                    except ValueError:
                        pass
            else:
                self.store.mark_played(game_id)
            self._active_game_sessions[game_id] = now

        # End sessions that disappeared; don't accrue time while a game is closed.
        for game_id in list(self._active_game_sessions):
            if game_id not in active_ids:
                self._active_game_sessions.pop(game_id, None)

        self._active_game_names = sorted(set(active_names), key=str.casefold)
        if self._active_game_names:
            shown = ", ".join(self._active_game_names[:2])
            if len(self._active_game_names) > 2:
                shown += f" +{len(self._active_game_names) - 2}"
            self.running_status.setText(f"● Läuft: {shown}")
            self.running_status.setStyleSheet("color:#54e6a5;font-size:9pt;font-weight:700;padding-right:10px")
        else:
            self.running_status.setText("● Kein Spiel aktiv")
            self.running_status.setStyleSheet("color:#8d9bb2;font-size:9pt;padding-right:10px")
        if active_ids or self._active_game_names:
            self.refresh()

    def launch_game(self, game: dict) -> None:
        path = Path(game.get("path", ""))
        if not path.exists():
            QMessageBox.warning(self, "Spiel nicht gefunden", "Der gespeicherte Installationspfad existiert nicht mehr. Bitte entferne den Eintrag und erkenne das Spiel erneut.")
            return
        try:
            target = str(game.get("launch_target") or "").strip()
            process = None
            if target.startswith(("steam://", "com.epicgames.launcher://")):
                if sys.platform == "win32":
                    os.startfile(target)
                else:
                    webbrowser.open(target)
            elif target:
                executable = Path(target)
                if not executable.is_file():
                    raise FileNotFoundError(f"Startdatei nicht gefunden: {target}")
                process = subprocess.Popen([str(executable)], cwd=str(executable.parent), shell=False)
            elif path.suffix.lower() == ".lnk":
                if sys.platform == "win32":
                    os.startfile(str(path))
                else:
                    raise OSError("Windows-Verknüpfungen können nur unter Windows gestartet werden.")
            elif path.is_file():
                process = subprocess.Popen([str(path)], cwd=str(path.parent), shell=False)
            else:
                raise OSError("Für dieses Spiel ist kein Startziel hinterlegt. Bitte füge die EXE-Datei manuell hinzu.")
            self.store.mark_played(str(game["id"]))
            self.refresh()
        except Exception as exc:
            QMessageBox.critical(self, "Spiel konnte nicht gestartet werden", str(exc))



class FriendPage(QWidget):
    """Online friends UI. Presence is intentionally marked unavailable until its own backend exists."""

    def __init__(self, user: dict, auth: AuthService):
        super().__init__()
        self.user = user or {}
        self.auth = auth
        self.service = FriendService(auth)
        self.search_results: list[dict] = []

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        content = QWidget()
        root = QVBoxLayout(content)
        root.setContentsMargins(4, 4, 10, 12)
        root.setSpacing(12)
        scroll.setWidget(content)
        outer.addWidget(scroll)

        title = QLabel("Freunde")
        title.setObjectName("Title")
        subtitle = QLabel("Finde Spieler, verwalte Anfragen und baue deine Gaming-Community auf.")
        subtitle.setObjectName("Muted")
        subtitle.setWordWrap(True)
        root.addWidget(title)
        root.addWidget(subtitle)

        search_panel = QFrame(objectName="Panel")
        search_box = QVBoxLayout(search_panel)
        search_box.addWidget(QLabel("SPIELERSUCHE"))
        search_row = QHBoxLayout()
        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("Anzeigename (mindestens 3 Zeichen)")
        self.search_input.setMaxLength(32)
        self.search_button = QPushButton("Suchen")
        self.search_button.setObjectName("Primary")
        self.search_button.clicked.connect(self.search_players)
        self.search_input.returnPressed.connect(self.search_players)
        search_row.addWidget(self.search_input, 1)
        search_row.addWidget(self.search_button)
        search_box.addLayout(search_row)
        self.search_status = QLabel("Suche nach Spielern über ihren Anzeigenamen.")
        self.search_status.setObjectName("Muted")
        self.search_status.setWordWrap(True)
        search_box.addWidget(self.search_status)
        self.results_layout = QVBoxLayout()
        self.results_layout.setSpacing(8)
        search_box.addLayout(self.results_layout)
        root.addWidget(search_panel)

        requests_panel = QFrame(objectName="Panel")
        requests_box = QVBoxLayout(requests_panel)
        requests_heading = QLabel("FREUNDSCHAFTSANFRAGEN")
        requests_heading.setObjectName("SectionTitle")
        requests_box.addWidget(requests_heading)
        self.requests_status = QLabel("Anfragen werden beim Aktualisieren geladen.")
        self.requests_status.setObjectName("Muted")
        self.requests_box.addWidget(self.requests_status)
        self.requests_layout = QVBoxLayout()
        self.requests_layout.setSpacing(8)
        requests_box.addLayout(self.requests_layout)
        root.addWidget(requests_panel)

        friends_panel = QFrame(objectName="Panel")
        friends_box = QVBoxLayout(friends_panel)
        friends_header = QHBoxLayout()
        friends_heading = QLabel("DEINE FREUNDE")
        friends_heading.setObjectName("SectionTitle")
        self.refresh_button = QPushButton("↻ Aktualisieren")
        self.refresh_button.clicked.connect(self.refresh_all)
        friends_header.addWidget(friends_heading, 1)
        friends_header.addWidget(self.refresh_button)
        friends_box.addLayout(friends_header)
        self.friends_status = QLabel("Deine Freundesliste wird geladen.")
        self.friends_status.setObjectName("Muted")
        friends_box.addWidget(self.friends_status)
        self.friends_layout = QVBoxLayout()
        self.friends_layout.setSpacing(8)
        friends_box.addLayout(self.friends_layout)
        root.addWidget(friends_panel)
        root.addStretch()

        self._show_access_state()


    def _show_access_state(self):
        if not self.user.get("id"):
            message = "Freundesystem: Melde dich an, um Spieler online zu suchen und Freundschaften zu verwalten."
            self.search_status.setText(message)
            self.requests_status.setText("Für Freundschaftsanfragen ist ein angemeldetes Konto erforderlich.")
            self.friends_status.setText("Melde dich an, um deine Online-Freundesliste zu laden.")
            self.search_button.setEnabled(False)
            self.refresh_button.setEnabled(False)
        elif not self.auth.configured:
            message = "Supabase ist noch nicht eingerichtet. Bitte prüfe deine .env-Datei."
            self.search_status.setText(message)
            self.requests_status.setText(message)
            self.friends_status.setText(message)
            self.search_button.setEnabled(False)
            self.refresh_button.setEnabled(False)

    @staticmethod
    def _initials(name: str) -> str:
        words = [part for part in (name or "Spieler").strip().split() if part]
        return "".join(word[0].upper() for word in words[:2]) or "?"

    def _clear_layout(self, layout: QVBoxLayout):
        while layout.count():
            item = layout.takeAt(0)
            widget = item.widget()
            if widget is not None:
                widget.deleteLater()

    def _player_card(self, name: str, detail: str, user_id: str, action_text: str | None = None, action=None) -> QFrame:
        card = QFrame(objectName="Panel")
        row = QHBoxLayout(card)
        avatar = QLabel(self._initials(name))
        avatar.setFixedSize(44, 44)
        avatar.setAlignment(Qt.AlignmentFlag.AlignCenter)
        avatar.setStyleSheet("background:#292044;border:1px solid #7658d8;border-radius:22px;color:#c6b5ff;font-weight:800;font-size:12pt")
        info = QVBoxLayout()
        name_label = QLabel(name or "Spieler")
        name_label.setStyleSheet("font-size:11pt;font-weight:700;color:#ffffff")
        detail_label = QLabel(detail)
        detail_label.setObjectName("Muted")
        detail_label.setWordWrap(True)
        info.addWidget(name_label)
        info.addWidget(detail_label)
        row.addWidget(avatar)
        row.addLayout(info, 1)
        if action_text and action:
            button = QPushButton(action_text)
            button.setObjectName("Primary")
            button.clicked.connect(action)
            row.addWidget(button)
        return card

    def _set_status(self, label: QLabel, text: str, error: bool = False):
        label.setText(text)
        label.setStyleSheet("color:#ff8f9f" if error else "color:#8d9bb5")

    def search_players(self):
        if not self.user.get("id") or not self.auth.configured:
            return
        query = self.search_input.text().strip()
        self._clear_layout(self.results_layout)
        self.search_button.setEnabled(False)
        self._set_status(self.search_status, "Suche läuft …")
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        try:
            self.search_results = self.service.search_players(query)
            if not self.search_results:
                self._set_status(self.search_status, "Keine Spieler mit diesem Anzeigenamen gefunden.")
            else:
                self._set_status(self.search_status, f"{len(self.search_results)} Spieler gefunden.")
                for player in self.search_results:
                    name = str(player.get("display_name") or "Spieler")
                    player_id = str(player.get("player_id") or "")
                    card = self._player_card(
                        name, "Profil · Online-Status wird in einem späteren Update ergänzt", player_id,
                        "＋ Anfrage senden",
                        lambda pid=player_id, pname=name: self.send_request(pid, pname),
                    )
                    self.results_layout.addWidget(card)
        except FriendError as exc:
            self._set_status(self.search_status, str(exc), True)
        finally:
            QApplication.restoreOverrideCursor()
            self.search_button.setEnabled(True)

    def send_request(self, player_id: str, player_name: str):
        try:
            self.service.send_friend_request(player_id)
            self._set_status(self.search_status, f"Freundschaftsanfrage an {player_name} gesendet.")
            self.refresh_requests()
        except FriendError as exc:
            self._set_status(self.search_status, str(exc), True)

    def refresh_requests(self):
        if not self.user.get("id") or not self.auth.configured:
            return
        self._clear_layout(self.requests_layout)
        try:
            requests_rows = self.service.list_requests()
            incoming = 0
            if not requests_rows:
                self._set_status(self.requests_status, "Keine offenen Freundschaftsanfragen.")
                return
            self._set_status(self.requests_status, f"{len(requests_rows)} offene Anfrage(n).")
            for request in requests_rows:
                name = str(request.get("other_display_name") or "Spieler")
                direction = str(request.get("direction") or "")
                request_id = str(request.get("request_id") or "")
                if direction == "incoming":
                    incoming += 1
                    card = self._player_card(name, "Eingehende Anfrage", str(request.get("other_user_id") or ""))
                    buttons = QHBoxLayout()
                    accept = QPushButton("Annehmen")
                    accept.setObjectName("Primary")
                    decline = QPushButton("Ablehnen")
                    accept.clicked.connect(lambda _=False, rid=request_id: self.respond_request(rid, True))
                    decline.clicked.connect(lambda _=False, rid=request_id: self.respond_request(rid, False))
                    buttons.addWidget(accept)
                    buttons.addWidget(decline)
                    card.layout().addLayout(buttons)
                else:
                    card = self._player_card(name, "Ausgehende Anfrage · wartet auf Antwort", str(request.get("other_user_id") or ""))
                    cancel = QPushButton("Zurückziehen")
                    cancel.clicked.connect(lambda _=False, rid=request_id: self.cancel_request(rid))
                    card.layout().addWidget(cancel)
                self.requests_layout.addWidget(card)
        except FriendError as exc:
            self._set_status(self.requests_status, str(exc), True)

    def respond_request(self, request_id: str, accept: bool):
        try:
            self.service.respond_to_request(request_id, accept)
            self._set_status(self.requests_status, "Anfrage angenommen." if accept else "Anfrage abgelehnt.")
            self.refresh_all()
        except FriendError as exc:
            self._set_status(self.requests_status, str(exc), True)

    def cancel_request(self, request_id: str):
        try:
            self.service.cancel_request(request_id)
            self._set_status(self.requests_status, "Anfrage zurückgezogen.")
            self.refresh_all()
        except FriendError as exc:
            self._set_status(self.requests_status, str(exc), True)

    @staticmethod
    def _last_seen_text(value: str | None) -> str:
        if not value:
            return ""
        try:
            stamp = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
            if stamp.tzinfo is None:
                stamp = stamp.astimezone()
            return stamp.astimezone().strftime("%d.%m.%Y · %H:%M")
        except (ValueError, TypeError, OverflowError):
            return ""

    def refresh_friends(self):
        if not self.user.get("id") or not self.auth.configured:
            return
        self._clear_layout(self.friends_layout)
        try:
            friends = self.service.list_friend_presence()
            if not friends:
                self._set_status(self.friends_status, "Noch keine Freunde. Suche oben nach Spielern.")
                return
            online_count = sum(1 for row in friends if row.get("is_online") is True)
            status_text = f"{len(friends)} Freund(e) · {online_count} online · Status aktualisiert"
            if getattr(self, "presence_error", ""):
                status_text += " · Dein Online-Status konnte nicht aktualisiert werden"
            self._set_status(self.friends_status, status_text)
            for friend in friends:
                name = str(friend.get("display_name") or "Spieler")
                online = friend.get("is_online") is True
                detail = "🟢 Online" if online else "⚪ Offline"
                if not online:
                    last_seen = self._last_seen_text(friend.get("last_seen"))
                    if last_seen:
                        detail += f" · zuletzt online {last_seen}"
                card = self._player_card(name, detail, str(friend.get("player_id") or ""))
                self.friends_layout.addWidget(card)
        except FriendError as exc:
            self._set_status(self.friends_status, str(exc), True)

    def refresh_all(self):
        if not self.user.get("id") or not self.auth.configured:
            return
        self.refresh_requests()
        self.refresh_friends()


class PresenceHeartbeat:
    """Thread-safe heartbeat runner; it never touches Qt widgets from the worker."""

    def __init__(self, service: FriendService, lock: threading.Lock, owner: "LauncherShell"):
        self.service = service
        self.lock = lock
        self.owner = owner

    def start(self) -> None:
        def run() -> None:
            try:
                self.service.update_presence()
                self.owner._presence_error = ""
            except FriendError as exc:
                self.owner._presence_error = str(exc)
            except Exception:
                self.owner._presence_error = "Online-Status konnte nicht aktualisiert werden."
            finally:
                self.lock.release()
        threading.Thread(target=run, daemon=True, name="EnderPresenceHeartbeat").start()


class LauncherShell(QWidget):
    signed_out = Signal()
    open_auth = Signal()
    presence_cleared = Signal()

    def __init__(self, user: dict, store: GameStore, auth: AuthService):
        super().__init__()
        self.user = user or {}
        self.store = store
        self.auth = auth
        root = QHBoxLayout(self)
        root.setContentsMargins(18, 18, 18, 18)
        root.setSpacing(16)
        sidebar = QFrame(objectName="Sidebar")
        sidebar.setFixedWidth(205)
        side = QVBoxLayout(sidebar)
        brand = QLabel("ENDER\n<span style='color:#9b7cff'>GAMING</span>")
        brand.setTextFormat(Qt.TextFormat.RichText)
        brand.setFont(QFont("Segoe UI", 17, QFont.Weight.Black))
        brand.setContentsMargins(12, 14, 8, 22)
        side.addWidget(brand)
        account_button = QPushButton("Anmelden / Registrieren")
        account_button.setObjectName("Primary")
        account_button.clicked.connect(self.open_auth.emit)
        side.addWidget(account_button)
        self.pages = QStackedWidget()
        self.home_page = self._home_page()
        self.library_page = GameLibraryPage(store)
        self.friends_page = FriendPage(self.user, auth)
        self.friends_page.presence_error = ""
        self.profile_page = self._profile_page()
        self.settings_page = self._settings_page()
        for page in (self.home_page, self.library_page, self.friends_page, self.profile_page, self.settings_page):
            self.pages.addWidget(page)
        self.nav_buttons = []
        for label, index in (("⌂  Startseite", 0), ("▣  Bibliothek", 1), ("♧  Freunde", 2), ("◎  Profil", 3), ("⚙  Einstellungen", 4)):
            button = QPushButton(label)
            button.setObjectName("Nav")
            button.setCheckable(True)
            button.clicked.connect(lambda checked=False, i=index: self.navigate(i))
            side.addWidget(button)
            self.nav_buttons.append(button)
        side.addStretch()
        user_email = (self.user.get("email") or "Gastmodus")
        who = QLabel(user_email)
        who.setObjectName("Muted")
        who.setWordWrap(True)
        side.addWidget(who)
        logout = QPushButton("Abmelden" if self.user.get("id") else "Gastmodus aktiv")
        logout.setObjectName("Danger")
        logout.setEnabled(bool(self.user.get("id")))
        logout.clicked.connect(self.signed_out.emit)
        side.addWidget(logout)
        root.addWidget(sidebar)
        root.addWidget(self.pages, 1)
        self.navigate(0)
        self.dashboard_timer = QTimer(self)
        self.dashboard_timer.setInterval(15000)
        self.dashboard_timer.timeout.connect(self._refresh_dashboard_if_visible)
        self.dashboard_timer.start()

        # Presence is opt-in by account state: guests never send heartbeats.
        self._presence_lock = threading.Lock()
        self._presence_error = ""
        self._presence_timer = QTimer(self)
        self._presence_timer.setInterval(60_000)
        self._presence_timer.timeout.connect(self._presence_tick)
        if self.user.get("id") and self.auth.configured:
            self._presence_tick()
            self._presence_timer.start()

    def _presence_tick(self) -> None:
        if not self.user.get("id") or not self.auth.configured:
            return
        self.friends_page.presence_error = self._presence_error
        if not self._presence_lock.acquire(blocking=False):
            return
        PresenceHeartbeat(self.friends_page.service, self._presence_lock, self).start()

    def stop_presence(self, clear_online_state: bool = False) -> bool:
        self._presence_timer.stop()
        if not clear_online_state or not self.user.get("id") or not self.auth.configured:
            return False
        service = self.friends_page.service
        lock = self._presence_lock
        def clear_when_ready() -> None:
            # Wait for any in-flight heartbeat, then delete the presence row while
            # the access token is still available. The logout UI continues on signal.
            with lock:
                try:
                    service.clear_presence()
                except FriendError:
                    pass
            self.presence_cleared.emit()
        threading.Thread(target=clear_when_ready, daemon=True, name="EnderPresenceLogout").start()
        return True

    def _refresh_dashboard_if_visible(self) -> None:
        if self.pages.currentIndex() == 0:
            self.update_home_stats(refresh_rows=False)

    def navigate(self, index: int) -> None:
        self.pages.setCurrentIndex(index)
        for i, button in enumerate(self.nav_buttons):
            button.setChecked(i == index)
        if index == 0:
            self.update_home_stats()
        if index == 1:
            self.library_page.refresh()
        if index == 2:
            self.friends_page.refresh_all()
        if index == 3:
            self.load_profile()

    def _home_page(self) -> QWidget:
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(4, 4, 10, 12)
        layout.setSpacing(14)

        hero = QFrame(objectName="Panel")
        hero.setMinimumHeight(190)
        hero_layout = QVBoxLayout(hero)
        eyebrow = QLabel("ENDERS STUDIOS  /  GAME CENTER")
        eyebrow.setObjectName("Muted")
        headline = QLabel("DEIN NÄCHSTES\nGAMING-ABENTEUER.")
        headline.setStyleSheet("font-size:27pt;font-weight:900;color:white")
        description = QLabel("Alle deine Spiele an einem Ort. Starte deine Sammlung und mach den Launcher zu deiner Zentrale.")
        description.setObjectName("Muted")
        description.setWordWrap(True)
        open_library = QPushButton("Zur Spielebibliothek  →")
        open_library.setObjectName("Primary")
        open_library.clicked.connect(lambda: self.navigate(1))
        hero_layout.addWidget(eyebrow)
        hero_layout.addWidget(headline)
        hero_layout.addWidget(description)
        hero_layout.addWidget(open_library, 0, Qt.AlignmentFlag.AlignLeft)
        layout.addWidget(hero)

        stats = QHBoxLayout()
        self.game_count = self._stat_card("SPIELE", "0")
        self.favorite_count = self._stat_card("FAVORITEN", "0")
        self.total_playtime_card = self._stat_card("SPIELZEIT GESAMT", "0 Min.")
        self.week_playtime_card = self._stat_card("DIESE WOCHE", "0 Min.")
        self.account_card = self._stat_card("ACCOUNT", "AKTIV" if self.user.get("id") else "LOKAL")
        stats.addWidget(self.game_count)
        stats.addWidget(self.favorite_count)
        stats.addWidget(self.total_playtime_card)
        stats.addWidget(self.week_playtime_card)
        stats.addWidget(self.account_card)
        layout.addLayout(stats)

        ranking_panel = QFrame(objectName="Panel")
        ranking_box = QVBoxLayout(ranking_panel)
        ranking_title = QLabel("MEISTGESPIELT")
        ranking_title.setObjectName("SectionTitle")
        ranking_box.addWidget(ranking_title)
        self.top_games_label = QLabel("Deine Spielzeit-Rangliste erscheint hier, sobald du Spiele gespielt hast.")
        self.top_games_label.setObjectName("Muted")
        self.top_games_label.setWordWrap(True)
        ranking_box.addWidget(self.top_games_label)
        layout.addWidget(ranking_panel)

        self.recent_row = self._home_game_section(
            layout, "WEITERSPIELEN", "Hier erscheinen Spiele, die du gestartet hast.")
        self.favorite_row = self._home_game_section(
            layout, "DEINE FAVORITEN", "Markiere Spiele in deiner Bibliothek mit dem Stern.")

        layout.addStretch()
        footer = QLabel(f"{APP_NAME}  •  Version {APP_VERSION}  •  Deine Spiele bleiben auf diesem PC gespeichert")
        footer.setObjectName("Muted")
        layout.addWidget(footer)
        scroll.setWidget(page)
        return scroll

    def _home_game_section(self, parent_layout: QVBoxLayout, title: str, empty_text: str) -> QHBoxLayout:
        heading = QHBoxLayout()
        label = QLabel(title)
        label.setObjectName("SectionTitle")
        heading.addWidget(label)
        heading.addStretch()
        show_all = QPushButton("Bibliothek öffnen  →")
        show_all.clicked.connect(lambda: self.navigate(1))
        heading.addWidget(show_all)
        parent_layout.addLayout(heading)

        area = QScrollArea()
        area.setWidgetResizable(True)
        area.setFixedHeight(222)
        area.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        area.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        content = QWidget()
        row = QHBoxLayout(content)
        row.setContentsMargins(0, 0, 0, 4)
        row.setSpacing(12)
        placeholder = QLabel(empty_text)
        placeholder.setObjectName("Muted")
        placeholder.setWordWrap(True)
        row.addWidget(placeholder)
        area.setWidget(content)
        parent_layout.addWidget(area)
        return row

    def _home_game_card(self, game: dict) -> QFrame:
        card = QFrame(objectName="Panel")
        card.setFixedWidth(188)
        box = QVBoxLayout(card)
        box.setContentsMargins(10, 10, 10, 10)
        box.setSpacing(7)
        cover = QLabel()
        cover.setFixedSize(164, 92)
        cover.setAlignment(Qt.AlignmentFlag.AlignCenter)
        GameLibraryPage._show_cover(cover, str(game.get("cover_path") or ""), "ENDER")
        box.addWidget(cover, 0, Qt.AlignmentFlag.AlignHCenter)

        name = QLabel(str(game.get("name") or "Unbekanntes Spiel"))
        name.setStyleSheet("font-size:10.5pt;font-weight:700;color:#ffffff")
        name.setWordWrap(True)
        name.setMinimumHeight(34)
        name.setMaximumHeight(42)
        box.addWidget(name)

        meta = QLabel(f"{game.get('source') or 'Manuell'}  •  {game.get('category') or 'Nicht kategorisiert'}")
        meta.setObjectName("Muted")
        meta.setWordWrap(True)
        meta.setMaximumHeight(30)
        box.addWidget(meta)

        play = QPushButton("▶  Starten")
        play.setObjectName("Primary")
        play.clicked.connect(lambda _=False, selected=dict(game): self._launch_from_home(selected))
        box.addWidget(play)
        return card

    def _refresh_home_row(self, row: QHBoxLayout, games: list[dict], empty_text: str) -> None:
        while row.count():
            item = row.takeAt(0)
            widget = item.widget()
            if widget is not None:
                widget.deleteLater()
        if not games:
            placeholder = QLabel(empty_text)
            placeholder.setObjectName("Muted")
            placeholder.setWordWrap(True)
            row.addWidget(placeholder)
            row.addStretch()
            return
        for game in games:
            row.addWidget(self._home_game_card(game))
        row.addStretch()

    def _launch_from_home(self, game: dict) -> None:
        self.library_page.launch_game(game)
        self.update_home_stats()

    def _stat_card(self, title: str, value: str) -> QFrame:
        card = QFrame(objectName="Panel")
        box = QVBoxLayout(card)
        label = QLabel(title)
        label.setObjectName("Muted")
        number = QLabel(value)
        number.setStyleSheet("font-size:22pt;font-weight:800;color:#b7a3ff")
        box.addWidget(label)
        box.addWidget(number)
        card.value_label = number
        return card

    @staticmethod
    def _format_dashboard_time(seconds: int) -> str:
        minutes = max(0, int(seconds)) // 60
        hours, remainder = divmod(minutes, 60)
        return f"{hours} Std. {remainder} Min." if hours else f"{remainder} Min."

    def update_home_stats(self, refresh_rows: bool = True) -> None:
        self.game_count.value_label.setText(str(len(self.store.games)))
        self.favorite_count.value_label.setText(str(sum(bool(g.get("favorite")) for g in self.store.games)))
        stats = self.store.get_playtime_stats()
        self.total_playtime_card.value_label.setText(self._format_dashboard_time(stats["total_seconds"]))
        self.week_playtime_card.value_label.setText(self._format_dashboard_time(stats["week_seconds"]))
        if stats["top_games"]:
            ranking = [f"{index}. {item['name']}  —  {self._format_dashboard_time(item['seconds'])}"
                       for index, item in enumerate(stats["top_games"], start=1)]
            self.top_games_label.setText("\n".join(ranking))
        else:
            self.top_games_label.setText("Deine Spielzeit-Rangliste erscheint hier, sobald du Spiele gespielt hast.")
        active = getattr(self.library_page, "_active_game_names", [])
        self.account_card.value_label.setText(f"{len(active)} AKTIV" if active else ("ONLINE" if self.user.get("id") else "LOKAL"))
        if refresh_rows:
            self._refresh_home_row(
                self.recent_row, self.store.get_recently_played(5),
                "Noch keine Spielhistorie. Starte ein Spiel aus deiner Bibliothek.",
            )
            self._refresh_home_row(
                self.favorite_row, self.store.get_favorites(5),
                "Noch keine Favoriten. Nutze den Stern neben einem Spiel in deiner Bibliothek.",
            )

    def _profile_page(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        title = QLabel("Spielerprofil")
        title.setObjectName("Title")
        panel = QFrame(objectName="Panel")
        box = QVBoxLayout(panel)

        name_label = QLabel("ANZEIGENAME")
        name_label.setObjectName("Muted")
        self.profile_name_input = QLineEdit()
        self.profile_name_input.setPlaceholderText("Dein Anzeigename")
        self.profile_name_input.setMaxLength(32)
        self.profile_name_input.setEnabled(bool(self.user.get("id")) and self.auth.configured)
        box.addWidget(name_label)
        box.addWidget(self.profile_name_input)
        box.addSpacing(10)

        for caption, value in (("E-MAIL", self.user.get("email") or "Nicht angemeldet"), ("USER-ID", self.user.get("id") or "Kein Konto angemeldet")):
            label = QLabel(caption)
            label.setObjectName("Muted")
            val = QLabel(str(value))
            val.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
            val.setStyleSheet("font-size:12pt;font-weight:600")
            box.addWidget(label)
            box.addWidget(val)
            box.addSpacing(10)

        self.profile_save_button = QPushButton("Profil speichern")
        self.profile_save_button.setObjectName("Primary")
        self.profile_save_button.setEnabled(bool(self.user.get("id")) and self.auth.configured)
        self.profile_save_button.clicked.connect(self.save_profile)
        box.addWidget(self.profile_save_button, 0, Qt.AlignmentFlag.AlignLeft)

        self.profile_status = QLabel(
            "Melde dich mit einem Konto an, um dein Online-Profil zu laden."
            if not self.user.get("id") else
            "Profil wird beim Öffnen dieser Seite aus Supabase geladen."
        )
        self.profile_status.setObjectName("Muted")
        self.profile_status.setWordWrap(True)
        box.addWidget(self.profile_status)

        layout.addWidget(title)
        layout.addWidget(panel)
        layout.addStretch()
        return page

    def load_profile(self) -> None:
        user_id = self.user.get("id")
        if not user_id:
            self.profile_status.setText("Für ein Online-Spielerprofil musst du angemeldet sein.")
            return
        if not self.auth.configured:
            self.profile_status.setText("Supabase ist noch nicht eingerichtet. Dein Online-Profil kann nicht geladen werden.")
            return
        self.profile_save_button.setEnabled(False)
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        try:
            profile = self.auth.get_profile(str(user_id))
            self.profile_name_input.setText(str(profile.get("display_name") or "Gaming-Spieler"))
            self.profile_status.setText("Profil erfolgreich aus Supabase geladen.")
        except AuthError as exc:
            self.profile_status.setText(f"Profil konnte nicht geladen werden: {exc}")
        finally:
            QApplication.restoreOverrideCursor()
            self.profile_save_button.setEnabled(True)

    def save_profile(self) -> None:
        user_id = self.user.get("id")
        if not user_id:
            return
        name = self.profile_name_input.text().strip()
        self.profile_save_button.setEnabled(False)
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        try:
            profile = self.auth.update_profile(str(user_id), name)
            self.profile_name_input.setText(str(profile.get("display_name") or name))
            metadata = self.user.setdefault("user_metadata", {})
            metadata["display_name"] = self.profile_name_input.text()
            self.profile_status.setText("Dein Anzeigename wurde sicher in deinem Supabase-Profil gespeichert.")
        except AuthError as exc:
            self.profile_status.setText(f"Speichern fehlgeschlagen: {exc}")
        finally:
            QApplication.restoreOverrideCursor()
            self.profile_save_button.setEnabled(True)

    def _settings_page(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        title = QLabel("Einstellungen")
        title.setObjectName("Title")
        panel = QFrame(objectName="Panel")
        box = QVBoxLayout(panel)
        box.addWidget(QLabel("Darstellung: Dunkles Gaming-Design"))
        info = QLabel("Spiele und Favoriten werden lokal in deiner Windows-Benutzerablage gespeichert. Passwörter werden nicht gespeichert; Sitzungstoken liegen im Windows Credential Manager.")
        info.setObjectName("Muted")
        info.setWordWrap(True)
        box.addWidget(info)
        layout.addWidget(title)
        layout.addWidget(panel)
        layout.addStretch()
        return page


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(APP_NAME)
        self.resize(1220, 790)
        self.setMinimumSize(900, 620)
        self.auth = AuthService()
        self.store = GameStore()
        self.stack = QStackedWidget()
        self.setCentralWidget(self.stack)
        self.login_page = LoginPage(self.auth)
        self.login_page.authenticated.connect(self.show_launcher)
        self.login_page.continue_as_guest.connect(lambda: self.show_launcher({}))
        self.stack.addWidget(self.login_page)
        self.shell: LauncherShell | None = None
        # The launcher is usable immediately; an account is optional.
        self.show_launcher({})
        if self.auth.configured:
            try:
                user = self.auth.restore_session()
                if user:
                    self.show_launcher(user)
            except AuthError:
                self.auth.sign_out()

    def show_launcher(self, user: dict) -> None:
        if self.shell:
            self.stack.removeWidget(self.shell)
            self.shell.deleteLater()
        self.shell = LauncherShell(user, self.store, self.auth)
        self.shell.signed_out.connect(self.logout)
        self.shell.presence_cleared.connect(self._finish_logout)
        self.shell.open_auth.connect(lambda: self.stack.setCurrentWidget(self.login_page))
        self.stack.addWidget(self.shell)
        self.stack.setCurrentWidget(self.shell)

    def logout(self) -> None:
        if self.shell and self.shell.stop_presence(clear_online_state=True):
            return
        self._finish_logout()

    def _finish_logout(self) -> None:
        self.auth.sign_out()
        self.show_launcher({})


def main() -> int:
    app = QApplication(sys.argv)
    app.setApplicationName(APP_NAME)
    app.setStyle("Fusion")
    app.setStyleSheet(STYLE)
    window = MainWindow()
    window.show()
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
