"""Bounded discovery of installed Windows games from launcher metadata.

No whole-drive crawl is performed. Steam/Epic metadata, known GOG/EA registry
locations, uninstall records, and the conventional XboxGames folders are used.
"""
from __future__ import annotations

import json
import os
import re
from pathlib import Path
from typing import Iterable, Mapping


def _unescape_vdf(value: str) -> str:
    return value.replace(r'\"', '"').replace(r'\\', '\\')


def parse_vdf_pairs(text: str) -> dict[str, str]:
    pattern = re.compile(r'"((?:\\.|[^"\\])*)"\s*"((?:\\.|[^"\\])*)"')
    return {_unescape_vdf(key): _unescape_vdf(value) for key, value in pattern.findall(text)}


def parse_steam_library_paths(text: str, steam_root: Path) -> list[Path]:
    libraries = [steam_root]
    for value in parse_vdf_pairs(text).values():
        if (":\\" in value or value.startswith("\\\\") or value.startswith("/")):
            candidate = Path(value)
            if candidate not in libraries:
                libraries.append(candidate)
    return libraries


def _windows_steam_roots() -> list[Path]:
    roots: list[Path] = []
    try:
        import winreg  # type: ignore[import-not-found]
        locations = (
            (winreg.HKEY_CURRENT_USER, r"Software\Valve\Steam", "SteamPath"),
            (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\WOW6432Node\Valve\Steam", "InstallPath"),
            (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Valve\Steam", "InstallPath"),
        )
        for hive, key_path, value_name in locations:
            try:
                with winreg.OpenKey(hive, key_path) as key:
                    value, _ = winreg.QueryValueEx(key, value_name)
                if value:
                    candidate = Path(os.path.expandvars(str(value)))
                    if candidate not in roots:
                        roots.append(candidate)
            except OSError:
                continue
    except ImportError:
        pass
    for env_name in ("ProgramFiles(x86)", "ProgramFiles", "LOCALAPPDATA"):
        base = os.environ.get(env_name)
        if base:
            candidate = Path(base) / "Steam"
            if candidate not in roots:
                roots.append(candidate)
    return [root for root in roots if root.exists()]


def detect_steam_games(steam_roots: Iterable[Path] | None = None) -> list[dict]:
    roots = list(steam_roots) if steam_roots is not None else _windows_steam_roots()
    found: dict[str, dict] = {}
    for steam_root in roots:
        steam_root = Path(steam_root)
        libraries = [steam_root]
        library_file = steam_root / "steamapps" / "libraryfolders.vdf"
        if library_file.is_file():
            try:
                libraries = parse_steam_library_paths(library_file.read_text(encoding="utf-8", errors="replace"), steam_root)
            except OSError:
                pass
        for library in libraries:
            steamapps = library / "steamapps"
            if not steamapps.is_dir():
                continue
            for manifest in steamapps.glob("appmanifest_*.acf"):
                try:
                    data = parse_vdf_pairs(manifest.read_text(encoding="utf-8", errors="replace"))
                    app_id, name, install_dir = (data.get(k, "").strip() for k in ("appid", "name", "installdir"))
                    if not app_id.isdigit() or not name or not install_dir:
                        continue
                    install_path = steamapps / "common" / install_dir
                    if not install_path.is_dir():
                        continue
                    uri = f"steam://rungameid/{app_id}"
                    found[uri.casefold()] = {"name": name, "path": str(install_path), "launch_target": uri, "source": "Steam", "app_id": app_id}
                except OSError:
                    continue
    return list(found.values())


def _default_epic_manifest_dirs() -> list[Path]:
    return [Path(os.environ.get("PROGRAMDATA", r"C:\ProgramData")) / "Epic" / "EpicGamesLauncher" / "Data" / "Manifests"]


def detect_epic_games(manifest_dirs: Iterable[Path] | None = None) -> list[dict]:
    directories = list(manifest_dirs) if manifest_dirs is not None else _default_epic_manifest_dirs()
    found: dict[str, dict] = {}
    for directory in directories:
        directory = Path(directory)
        if not directory.is_dir():
            continue
        for manifest in directory.glob("*.item"):
            try:
                data = json.loads(manifest.read_text(encoding="utf-8"))
                if not isinstance(data, dict):
                    continue
                name = str(data.get("DisplayName") or "").strip()
                install_location = str(data.get("InstallLocation") or "").strip()
                app_name = str(data.get("AppName") or data.get("ArtifactId") or "").strip()
                if not name or not install_location:
                    continue
                install_path = Path(os.path.expandvars(install_location))
                if not install_path.is_dir():
                    continue
                launch_executable = str(data.get("LaunchExecutable") or "").strip()
                executable = install_path / launch_executable if launch_executable else None
                target = (f"com.epicgames.launcher://apps/{app_name}?action=launch&silent=true" if app_name
                          else str(executable) if executable and executable.is_file() else "")
                if target:
                    found[target.casefold()] = {"name": name, "path": str(install_path), "launch_target": target, "source": "Epic Games"}
            except (OSError, json.JSONDecodeError, TypeError, ValueError):
                continue
    return list(found.values())


def _read_registry_game_keys(key_records: Iterable[Mapping[str, str]]) -> list[dict]:
    """Convert registry-like records into game entries; separated for unit testing."""
    found: dict[str, dict] = {}
    for record in key_records:
        name = str(record.get("name") or record.get("DisplayName") or record.get("gameName") or "").strip()
        raw_path = str(record.get("path") or record.get("InstallLocation") or record.get("Install Dir") or "").strip().strip('"')
        exe = str(record.get("exe") or record.get("LaunchExecutable") or "").strip().strip('"')
        if not name or not raw_path:
            continue
        install_path = Path(os.path.expandvars(raw_path))
        if not install_path.is_dir():
            continue
        executable = Path(exe) if exe else None
        if executable and not executable.is_absolute():
            executable = install_path / executable
        if not executable or not executable.is_file():
            try:
                executable = next(p for p in install_path.iterdir() if p.is_file() and p.suffix.casefold() == ".exe")
            except (OSError, StopIteration):
                continue
        target = str(executable.resolve())
        found[target.casefold()] = {"name": name, "path": str(install_path), "launch_target": target, "source": str(record.get("source") or "")}
    return list(found.values())


def _windows_registry_records() -> list[dict[str, str]]:
    try:
        import winreg  # type: ignore[import-not-found]
    except ImportError:
        return []

    records: list[dict[str, str]] = []
    hives = (winreg.HKEY_LOCAL_MACHINE, winreg.HKEY_CURRENT_USER)
    # Native launcher-specific locations are more reliable than display-name heuristics.
    game_keys = (
        (r"SOFTWARE\GOG.com\Games", "GOG"),
        (r"SOFTWARE\WOW6432Node\GOG.com\Games", "GOG"),
        (r"SOFTWARE\EA Games", "EA app"),
        (r"SOFTWARE\WOW6432Node\EA Games", "EA app"),
    )
    for hive in hives:
        for base_key, source in game_keys:
            try:
                with winreg.OpenKey(hive, base_key) as parent:
                    count = winreg.QueryInfoKey(parent)[0]
                    for index in range(count):
                        try:
                            sub_name = winreg.EnumKey(parent, index)
                            with winreg.OpenKey(parent, sub_name) as child:
                                values = {}
                                for value_name in ("gameName", "name", "path", "exe", "Install Dir", "InstallDir"):
                                    try:
                                        values[value_name], _ = winreg.QueryValueEx(child, value_name)
                                    except OSError:
                                        pass
                            records.append({"name": str(values.get("gameName") or values.get("name") or sub_name),
                                            "path": str(values.get("path") or values.get("Install Dir") or values.get("InstallDir") or ""),
                                            "exe": str(values.get("exe") or ""), "source": source})
                        except OSError:
                            continue
            except OSError:
                continue

        # Xbox PC games are registered in the standard uninstall inventory on some builds.
        uninstall_keys = (r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall",
                          r"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall")
        for base_key in uninstall_keys:
            try:
                with winreg.OpenKey(hive, base_key) as parent:
                    count = winreg.QueryInfoKey(parent)[0]
                    for index in range(count):
                        try:
                            sub_name = winreg.EnumKey(parent, index)
                            with winreg.OpenKey(parent, sub_name) as child:
                                values = {}
                                for value_name in ("DisplayName", "Publisher", "InstallLocation", "DisplayIcon"):
                                    try:
                                        values[value_name], _ = winreg.QueryValueEx(child, value_name)
                                    except OSError:
                                        pass
                            publisher = str(values.get("Publisher") or "").casefold()
                            display_name = str(values.get("DisplayName") or "").strip()
                            if display_name and any(token in publisher for token in ("gog", "electronic arts", "ea games", "xbox", "microsoft studios")):
                                records.append({"name": display_name, "path": str(values.get("InstallLocation") or ""),
                                                "exe": str(values.get("DisplayIcon") or ""),
                                                "source": "GOG" if "gog" in publisher else "EA app" if ("electronic arts" in publisher or "ea games" in publisher) else "Xbox"})
                        except OSError:
                            continue
            except OSError:
                continue
    return records


def detect_registry_games(key_records: Iterable[Mapping[str, str]] | None = None) -> list[dict]:
    """Discover GOG/EA/Xbox games from known Windows registry records."""
    return _read_registry_game_keys(_windows_registry_records() if key_records is None else key_records)


def _xbox_game_roots() -> list[Path]:
    roots: list[Path] = []
    for env_name in ("ProgramFiles", "ProgramFiles(x86)"):
        base = os.environ.get(env_name)
        if base:
            roots.append(Path(base) / "XboxGames")
    # Xbox app commonly creates X:\XboxGames on user-selected library drives.
    # Only inspect this exact conventional folder, never arbitrary drive contents.
    if os.name == "nt":
        try:
            import ctypes
            mask = ctypes.windll.kernel32.GetLogicalDrives()
            for index in range(26):
                if mask & (1 << index):
                    roots.append(Path(f"{chr(65 + index)}:/XboxGames"))
        except Exception:
            pass
    unique = {str(p).casefold(): p for p in roots if p.is_dir()}
    return list(unique.values())


def detect_xbox_folder_games(roots: Iterable[Path] | None = None) -> list[dict]:
    """Detect conventional XboxGames installs; search at most 3 levels per title."""
    found: dict[str, dict] = {}
    for root in (list(roots) if roots is not None else _xbox_game_roots()):
        root = Path(root)
        if not root.is_dir():
            continue
        try:
            titles = [p for p in root.iterdir() if p.is_dir()]
        except OSError:
            continue
        for title_dir in titles:
            executable = None
            try:
                for current, dirs, files in os.walk(title_dir):
                    depth = len(Path(current).relative_to(title_dir).parts)
                    if depth >= 3:
                        dirs[:] = []
                    dirs[:] = [d for d in dirs if d.casefold() not in {"redist", "redistributables", "easyanticheat", "support"}]
                    candidates = [f for f in files if f.casefold().endswith(".exe") and not f.casefold().startswith(("unins", "setup", "vc_redist"))]
                    if candidates:
                        executable = Path(current) / sorted(candidates, key=str.casefold)[0]
                        break
            except OSError:
                continue
            if executable:
                target = str(executable.resolve())
                found[target.casefold()] = {"name": title_dir.name, "path": str(title_dir), "launch_target": target, "source": "Xbox"}
    return list(found.values())


def detect_installed_games() -> list[dict]:
    combined: dict[str, dict] = {}
    discovered = detect_steam_games() + detect_epic_games() + detect_registry_games() + detect_xbox_folder_games()
    for game in discovered:
        key = str(game.get("launch_target") or game.get("path") or "").casefold()
        if key:
            combined[key] = game
    return sorted(combined.values(), key=lambda game: str(game.get("name", "")).casefold())
