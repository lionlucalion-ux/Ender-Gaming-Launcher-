from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path

from game_detection import (detect_epic_games, detect_steam_games, detect_registry_games,
                             detect_xbox_folder_games, parse_steam_library_paths)


class GameDetectionTests(unittest.TestCase):
    def test_steam_library_paths(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp) / "Steam"
            text = f'''"libraryfolders" {{
                "0" {{ "path" "{str(root).replace(chr(92), chr(92)*2)}" }}
                "1" {{ "path" "D:\\\\SteamLibrary" }}
            }}'''
            libraries = parse_steam_library_paths(text, root)
            self.assertIn(root, libraries)
            self.assertTrue(any(str(path).endswith("SteamLibrary") for path in libraries))

    def test_detect_steam_manifest(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp) / "Steam"
            apps = root / "steamapps"
            game_dir = apps / "common" / "Example Game"
            game_dir.mkdir(parents=True)
            (apps / "appmanifest_123.acf").write_text(
                '"AppState" { "appid" "123" "name" "Example Game" "installdir" "Example Game" }',
                encoding="utf-8",
            )
            games = detect_steam_games([root])
            self.assertEqual(len(games), 1)
            self.assertEqual(games[0]["name"], "Example Game")
            self.assertEqual(games[0]["launch_target"], "steam://rungameid/123")
            self.assertEqual(games[0]["app_id"], "123")

    def test_detect_epic_manifest(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            install = root / "ExampleEpicGame"
            install.mkdir()
            manifest_dir = root / "Manifests"
            manifest_dir.mkdir()
            manifest = {
                "DisplayName": "Example Epic Game",
                "InstallLocation": str(install),
                "AppName": "ExampleEpicApp",
            }
            (manifest_dir / "example.item").write_text(json.dumps(manifest), encoding="utf-8")
            games = detect_epic_games([manifest_dir])
            self.assertEqual(len(games), 1)
            self.assertEqual(games[0]["name"], "Example Epic Game")
            self.assertIn("ExampleEpicApp", games[0]["launch_target"])

    def test_detect_gog_and_ea_registry_records(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            gog_dir = root / "GOGGame"
            ea_dir = root / "EAGame"
            gog_dir.mkdir(); ea_dir.mkdir()
            (gog_dir / "gog.exe").write_bytes(b"exe")
            (ea_dir / "ea.exe").write_bytes(b"exe")
            games = detect_registry_games([
                {"name": "GOG Sample", "path": str(gog_dir), "exe": "gog.exe", "source": "GOG"},
                {"name": "EA Sample", "path": str(ea_dir), "exe": "ea.exe", "source": "EA app"},
            ])
            self.assertEqual({game["source"] for game in games}, {"GOG", "EA app"})
            self.assertEqual({game["name"] for game in games}, {"GOG Sample", "EA Sample"})
            self.assertTrue(all(Path(game["launch_target"]).is_file() for game in games))

    def test_detect_xboxgames_folder(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp) / "XboxGames"
            install = root / "Sample Xbox Title" / "Content"
            install.mkdir(parents=True)
            (install / "Game.exe").write_bytes(b"exe")
            games = detect_xbox_folder_games([root])
            self.assertEqual(len(games), 1)
            self.assertEqual(games[0]["name"], "Sample Xbox Title")
            self.assertEqual(games[0]["source"], "Xbox")
            self.assertTrue(games[0]["launch_target"].endswith("Game.exe"))

    def test_xbox_scan_ignores_non_executable_folders(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp) / "XboxGames"
            (root / "NotAGame").mkdir(parents=True)
            (root / "NotAGame" / "readme.txt").write_text("no executable", encoding="utf-8")
            self.assertEqual(detect_xbox_folder_games([root]), [])


if __name__ == "__main__":
    unittest.main()
