import unittest
from unittest.mock import patch

from friend_service import FriendError, FriendService
from tests_friend_service import FakeAuth, FakeResponse


class FriendPresenceServiceTests(unittest.TestCase):
    def setUp(self):
        self.service = FriendService(FakeAuth())

    def test_update_presence_calls_rpc_and_returns_true(self):
        with patch("friend_service.requests.post", return_value=FakeResponse(200, True)) as post:
            self.assertTrue(self.service.update_presence())
        self.assertTrue(post.call_args.args[0].endswith("/rpc/update_friend_presence"))
        self.assertEqual(post.call_args.kwargs["json"], {})

    def test_clear_presence_calls_rpc(self):
        with patch("friend_service.requests.post", return_value=FakeResponse(200, True)) as post:
            self.assertTrue(self.service.clear_presence())
        self.assertTrue(post.call_args.args[0].endswith("/rpc/clear_friend_presence"))

    def test_list_friend_presence_returns_rows(self):
        rows = [
            {"player_id": "11111111-1111-4111-8111-111111111111", "display_name": "Friend", "last_seen": None, "is_online": False}
        ]
        with patch("friend_service.requests.post", return_value=FakeResponse(200, rows)) as post:
            self.assertEqual(self.service.list_friend_presence(), rows)
        self.assertTrue(post.call_args.args[0].endswith("/rpc/list_friend_presence"))

    def test_presence_rejects_malformed_rows(self):
        with patch("friend_service.requests.post", return_value=FakeResponse(200, {"unexpected": True})):
            with self.assertRaises(FriendError):
                self.service.list_friend_presence()

    def test_presence_errors_are_friendly(self):
        with patch("friend_service.requests.post", return_value=FakeResponse(404, {"message": "presence migration missing"})):
            with self.assertRaisesRegex(FriendError, "presence migration missing"):
                self.service.update_presence()


if __name__ == "__main__":
    unittest.main()
