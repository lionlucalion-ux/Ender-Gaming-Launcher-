"""Safe, bounded matching of running Windows processes to installed games."""
from __future__ import annotations

import os
from pathlib import Path
from typing import Iterable, Mapping


def process_matches_game(executable: str, game: Mapping[str, object]) -> bool:
    """Return True only when a process executable belongs to this game's path.

    A game path may be an executable (manual entry) or an installation folder
    (Steam/Epic discovery). No process-name-only guesses are made.
    """
    raw_exe = str(executable or "").strip().strip('"')
    raw_game_path = str(game.get("path") or "").strip().strip('"')
    if not raw_exe or not raw_game_path:
        return False
    try:
        exe = os.path.normcase(os.path.abspath(os.path.expandvars(raw_exe)))
        game_path = os.path.normcase(os.path.abspath(os.path.expandvars(raw_game_path)))
        if os.path.isfile(game_path):
            return exe == game_path
        return os.path.commonpath((exe, game_path)) == game_path
    except (OSError, ValueError):
        return False


def match_running_processes(
    games: Iterable[Mapping[str, object]],
    processes: Iterable[tuple[int, str]],
) -> dict[str, set[int]]:
    """Map game IDs to process IDs, suitable for deterministic unit tests."""
    result: dict[str, set[int]] = {}
    game_list = list(games)
    for pid, executable in processes:
        for game in game_list:
            game_id = str(game.get("id") or "")
            if game_id and process_matches_game(executable, game):
                result.setdefault(game_id, set()).add(int(pid))
    return result
