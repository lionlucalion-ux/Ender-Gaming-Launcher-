from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from process_monitor import match_running_processes, process_matches_game


class ProcessMonitorTests(unittest.TestCase):
    def test_matches_executable_inside_install_folder(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp) / "Game"
            exe = root / "Binaries" / "Game.exe"
            exe.parent.mkdir(parents=True)
            exe.touch()
            game = {"id": "g1", "path": str(root)}
            self.assertTrue(process_matches_game(str(exe), game))

    def test_matches_exact_manual_executable(self):
        with tempfile.TemporaryDirectory() as tmp:
            exe = Path(tmp) / "Manual.exe"
            exe.touch()
            self.assertTrue(process_matches_game(str(exe), {"id": "g", "path": str(exe)}))

    def test_does_not_match_neighbor_folder_or_name_only(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp) / "Game"
            neighbor = Path(tmp) / "GameBackup" / "Game.exe"
            neighbor.parent.mkdir()
            neighbor.touch()
            game = {"id": "g1", "path": str(root)}
            self.assertFalse(process_matches_game(str(neighbor), game))
            self.assertFalse(process_matches_game("Game.exe", game))

    def test_maps_multiple_processes_to_game(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp) / "Game"
            exe1, exe2 = root / "Game.exe", root / "Launcher.exe"
            root.mkdir()
            exe1.touch(); exe2.touch()
            games = [{"id": "game-1", "path": str(root)}]
            result = match_running_processes(games, [(101, str(exe1)), (102, str(exe2))])
            self.assertEqual(result, {"game-1": {101, 102}})


if __name__ == "__main__":
    unittest.main()
