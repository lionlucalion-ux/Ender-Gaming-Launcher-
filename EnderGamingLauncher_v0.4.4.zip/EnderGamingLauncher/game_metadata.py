"""Optional Steam metadata lookup for Ender Gaming Launcher.

The public Steam Store appdetails endpoint is used only for Steam app IDs.
No API key, account token, or password is sent. Network access is optional:
manual metadata editing remains available when the endpoint is unreachable.
"""
from __future__ import annotations

import html
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable
from urllib.parse import urlparse

import requests
from platformdirs import user_data_dir

STEAM_APP_ID_RE = re.compile(r"^[0-9]{1,12}$")
MAX_METADATA_RESPONSE_BYTES = 2 * 1024 * 1024
MAX_COVER_BYTES = 12 * 1024 * 1024
USER_AGENT = "EnderGamingLauncher/0.3.2 (game metadata lookup)"


class MetadataError(Exception):
    """A readable error from the optional metadata provider."""


def _clean_text(value: Any, limit: int) -> str:
    text = html.unescape(str(value or ""))
    text = re.sub(r"<[^>]*>", " ", text)
    text = " ".join(text.split())
    return text[:limit]


def _steam_app_id(value: Any) -> str:
    app_id = str(value or "").strip()
    if not STEAM_APP_ID_RE.fullmatch(app_id):
        raise MetadataError("Die Steam-App-ID ist ungültig.")
    return app_id


def _safe_steam_image_url(value: Any) -> str:
    candidate = str(value or "").strip()
    if not candidate:
        return ""
    try:
        parsed = urlparse(candidate)
    except ValueError:
        return ""
    host = (parsed.hostname or "").casefold()
    if parsed.scheme != "https" or not host or parsed.username or parsed.password:
        return ""
    if not (host == "steamstatic.com" or host.endswith(".steamstatic.com") or
            host == "akamaihd.net" or host.endswith(".akamaihd.net")):
        return ""
    return candidate[:1000]


def parse_steam_appdetails(app_id: str, payload: Any) -> dict[str, Any]:
    """Validate and normalize a Steam Store appdetails response."""
    safe_id = _steam_app_id(app_id)
    if not isinstance(payload, dict):
        raise MetadataError("Steam hat keine gültigen Spieldaten zurückgegeben.")
    entry = payload.get(safe_id)
    if not isinstance(entry, dict) or entry.get("success") is not True:
        raise MetadataError("Für diese Steam-App sind keine öffentlichen Spieldaten verfügbar.")
    data = entry.get("data")
    if not isinstance(data, dict):
        raise MetadataError("Die Steam-Antwort enthält keine Spieldetails.")

    genres: list[str] = []
    raw_genres = data.get("genres")
    if isinstance(raw_genres, list):
        for item in raw_genres:
            if isinstance(item, dict):
                name = _clean_text(item.get("description"), 40)
                if name and name not in genres:
                    genres.append(name)
            if len(genres) >= 12:
                break

    release = data.get("release_date")
    release_date = _clean_text(release.get("date"), 100) if isinstance(release, dict) else ""
    developers = data.get("developers") if isinstance(data.get("developers"), list) else []
    publishers = data.get("publishers") if isinstance(data.get("publishers"), list) else []
    website = str(data.get("website") or "").strip()
    if website:
        try:
            parsed_website = urlparse(website)
            if parsed_website.scheme not in {"http", "https"} or not parsed_website.hostname or parsed_website.username or parsed_website.password:
                website = ""
        except ValueError:
            website = ""

    return {
        "metadata_title": _clean_text(data.get("name"), 200),
        "developer": ", ".join(_clean_text(item, 100) for item in developers if _clean_text(item, 100))[:200],
        "publisher": ", ".join(_clean_text(item, 100) for item in publishers if _clean_text(item, 100))[:200],
        "release_date": release_date,
        "genres": genres,
        "description": _clean_text(data.get("short_description") or data.get("detailed_description"), 4000),
        "website": website[:300],
        "header_image_url": _safe_steam_image_url(data.get("header_image")),
        "metadata_source": "Steam Store",
        "metadata_updated_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
    }


def fetch_steam_metadata(
    app_id: str,
    *,
    http_get: Callable[..., Any] = requests.get,
) -> dict[str, Any]:
    """Fetch German Steam Store metadata with short timeouts and bounded body size."""
    safe_id = _steam_app_id(app_id)
    try:
        response = http_get(
            "https://store.steampowered.com/api/appdetails",
            params={"appids": safe_id, "cc": "de", "l": "german"},
            headers={"User-Agent": USER_AGENT, "Accept": "application/json"},
            timeout=(3, 6), allow_redirects=False,
        )
    except requests.RequestException as exc:
        raise MetadataError("Steam ist momentan nicht erreichbar. Prüfe deine Internetverbindung.") from exc
    if not getattr(response, "ok", False) or getattr(response, "status_code", 200) != 200:
        status = getattr(response, "status_code", "?")
        raise MetadataError(f"Steam konnte die Spieldaten nicht liefern (HTTP {status}).")
    content = getattr(response, "content", b"")
    if isinstance(content, bytes) and len(content) > MAX_METADATA_RESPONSE_BYTES:
        raise MetadataError("Die Steam-Antwort ist unerwartet groß und wurde abgelehnt.")
    try:
        payload = response.json()
    except (ValueError, AttributeError) as exc:
        raise MetadataError("Steam hat keine gültige JSON-Antwort gesendet.") from exc
    return parse_steam_appdetails(safe_id, payload)


def _is_image_bytes(data: bytes) -> bool:
    return (
        data.startswith(b"\xff\xd8\xff") or data.startswith(b"\x89PNG\r\n\x1a\n") or
        data.startswith((b"GIF87a", b"GIF89a")) or
        (len(data) >= 12 and data[:4] == b"RIFF" and data[8:12] == b"WEBP")
    )


def _download_bounded(url: str, *, http_get: Callable[..., Any]) -> bytes:
    parsed = urlparse(url)
    host = (parsed.hostname or "").casefold()
    if parsed.scheme != "https" or not (host == "steamstatic.com" or host.endswith(".steamstatic.com") or host == "akamaihd.net" or host.endswith(".akamaihd.net")):
        raise MetadataError("Die Cover-Adresse ist keine erlaubte Steam-Bildadresse.")
    try:
        response = http_get(
            url, headers={"User-Agent": USER_AGENT}, timeout=(3, 6), stream=True,
            allow_redirects=False,
        )
    except requests.RequestException as exc:
        raise MetadataError("Das Steam-Cover konnte nicht geladen werden.") from exc
    if not getattr(response, "ok", False) or getattr(response, "status_code", 200) != 200:
        raise MetadataError("Für dieses Spiel ist aktuell kein automatisches Cover verfügbar.")
    headers = getattr(response, "headers", {}) or {}
    try:
        declared = int(headers.get("Content-Length", "0") or 0)
    except (TypeError, ValueError):
        declared = 0
    if declared > MAX_COVER_BYTES:
        raise MetadataError("Das heruntergeladene Cover überschreitet 12 MB.")

    chunks: list[bytes] = []
    total = 0
    iterator = getattr(response, "iter_content", None)
    if callable(iterator):
        try:
            for chunk in iterator(64 * 1024):
                if not chunk:
                    continue
                total += len(chunk)
                if total > MAX_COVER_BYTES:
                    raise MetadataError("Das heruntergeladene Cover überschreitet 12 MB.")
                chunks.append(chunk)
        except requests.RequestException as exc:
            raise MetadataError("Der Steam-Cover-Download wurde unterbrochen.") from exc
        data = b"".join(chunks)
    else:
        data = getattr(response, "content", b"")
        if len(data) > MAX_COVER_BYTES:
            raise MetadataError("Das heruntergeladene Cover überschreitet 12 MB.")
    content_type = str(headers.get("Content-Type", "")).casefold()
    if not content_type.startswith("image/") or not _is_image_bytes(data):
        raise MetadataError("Steam hat keine gültige Bilddatei geliefert.")
    return data


def download_steam_cover(
    app_id: str,
    fallback_url: str = "",
    *,
    cache_dir: Path | str | None = None,
    http_get: Callable[..., Any] = requests.get,
) -> str:
    """Download a portrait Steam library image into the user's local cache.

    If the portrait image is unavailable, the validated Steam header image is
    used as a fallback. Returns an empty string if neither image is available.
    """
    safe_id = _steam_app_id(app_id)
    urls = [f"https://cdn.cloudflare.steamstatic.com/steam/apps/{safe_id}/library_600x900.jpg"]
    safe_fallback = _safe_steam_image_url(fallback_url)
    if safe_fallback:
        urls.append(safe_fallback)
    for url in urls:
        try:
            image_data = _download_bounded(url, http_get=http_get)
        except MetadataError:
            continue
        if cache_dir is None:
            folder = Path(user_data_dir("EnderGamingLauncher", "EndersStudios")) / "metadata_covers"
        else:
            folder = Path(cache_dir)
        folder.mkdir(parents=True, exist_ok=True)
        if image_data.startswith(b"\x89PNG\r\n\x1a\n"):
            suffix = ".png"
        elif image_data.startswith((b"GIF87a", b"GIF89a")):
            suffix = ".gif"
        elif len(image_data) >= 12 and image_data[:4] == b"RIFF" and image_data[8:12] == b"WEBP":
            suffix = ".webp"
        else:
            suffix = ".jpg"
        target = folder / f"steam_{safe_id}{suffix}"
        temporary = target.with_suffix(target.suffix + ".tmp")
        temporary.write_bytes(image_data)
        temporary.replace(target)
        return str(target.resolve())
    return ""
