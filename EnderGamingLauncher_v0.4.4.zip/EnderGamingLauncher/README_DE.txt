ENDER GAMING LAUNCHER – VERSION 0.4.4
====================================

NEU IN 0.4.1
------------
- Supabase-Konfiguration wird vor Netzwerkzugriff strenger geprüft.
- Akzeptiert werden neue sb_publishable_-Keys oder ältere Supabase-JWTs mit role=anon.
- Secret-/service_role-Keys und nicht öffentliche bzw. fehlerhafte Schlüssel werden abgewiesen.
- Die URL muss HTTPS und eine Supabase-Projektadresse sein; Beispielwerte werden erkannt.
- Die Validierung liegt in auth_config.py und ist unabhängig von der GUI testbar.

NEU IN 0.4.4
------------
- Freundes-Online-Status mit Supabase Presence-Heartbeat ergänzt.
- Ein angemeldeter Launcher sendet alle 60 Sekunden einen Heartbeat; Freunde gelten 3 Minuten nach dem letzten Heartbeat als online.
- Freundesliste zeigt Online/Offline und bei Offline-Freunden den letzten bekannten Zeitpunkt.
- Beim Abmelden wird der Presence-Eintrag gelöscht; Gäste senden keine Heartbeats.
- Neue Migration: supabase/migrations/20261121000000_create_friend_presence.sql.
- Presence-Tabelle ist nicht direkt lesbar/schreibbar; Zugriff erfolgt über authentifizierte RPC-Funktionen.
- Live-Status wurde als separate Funktion ergänzt; Profilbilder und Game-Status sind weiterhin offen.

NEU IN 0.4.3
------------
- Freundesseite in die Hauptnavigation integriert.
- Spielersuche mit Anzeigename (3–32 Zeichen), Ergebnisse mit Anfrage senden.
- Eingehende Freundschaftsanfragen annehmen oder ablehnen.
- Ausgehende Anfragen anzeigen und zurückziehen.
- Freundesliste mit Avatar-Platzhalter (Initialen) und Status-Hinweis.
- Der Online-/Offline-Status wurde in Version 0.4.4 ergänzt.
- Die Freundesseite ist scrollbar und zeigt Statusmeldungen bei Fehlern.
- Gastzugang bleibt bestehen; Freundesfunktionen sind nur mit Konto und Supabase-Konfiguration verfügbar.

NEU IN 0.4.2
------------
- Neue FriendService-Datenebene für Spielersuche, Freundesliste, offene Anfragen, Annehmen/Ablehnen und Zurückziehen eigener Anfragen.
- Neue Supabase-Migration erstellt eine private Freundschaftsanfragen-Tabelle und sichere RPC-Funktionen.
- Direkte Schreibrechte auf Freundschaftsanfragen sind für Desktop-Nutzer gesperrt; Änderungen laufen über authentifizierte Funktionen.
- Die Spielersuche gibt nur Spieler-ID und Anzeigenamen zurück; E-Mail-Adressen werden nicht offengelegt.
- Access-Tokens werden für jeden Aufruf aus dem Windows Credential Manager gelesen; bei HTTP 401 wird die Sitzung einmal erneuert.
- OAuth-/Session- und Gastzugang-Auswahl der bestehenden Version wurden in diesem Schritt nicht verändert.
- Die Oberfläche ist noch nicht mit der neuen Freundesdatenebene verbunden; das ist der nächste Integrationsschritt.

NEU IN 0.4.0
------------
- Dashboard zeigt Gesamtspielzeit und Spielzeit der aktuellen Kalenderwoche.
- Zusätzlich wird die heutige Spielzeit lokal pro Spiel erfasst.
- Spielzeit-Rangfolge der meistgespielten Titel steht über GameStore.get_playtime_stats() bereit.
- Dashboard aktualisiert seine Kennzahlen automatisch alle 15 Sekunden, wenn die Startseite geöffnet ist.
- Bestehende games.json-Dateien erhalten daily_playtime automatisch; vorhandene Gesamtspielzeiten bleiben erhalten.
- Die Spielzeit bleibt eine Näherung anhand erkannter Prozesse und ist keine Messung der aktiven Eingabezeit.

====================================

NEU IN 0.3.2
------------
- Erkannte Steam-Spiele übernehmen jetzt zusätzlich ihre Steam-App-ID; ältere Steam-Einträge erhalten die ID beim Laden aus ihrem steam://rungameid/-Startziel.
- In der Detailansicht können öffentliche Steam-Store-Daten (deutscher Titel, Entwickler, Publisher, Erscheinungsdatum, Genres, Beschreibung und Website) geladen werden.
- Der Metadatenabruf läuft in einem Hintergrundthread, damit die Oberfläche bedienbar bleibt.
- Ein passendes Steam-Bibliothekscover wird optional in den lokalen App-Daten zwischengespeichert; wenn kein Porträtcover verfügbar ist, wird das Steam-Headerbild als Fallback versucht.
- Für Xbox-, Epic-, GOG-, EA- und manuell hinzugefügte Spiele lassen sich dieselben Informationsfelder manuell bearbeiten.
- Metadaten werden lokal in games.json gespeichert; Netzwerkabruf ist optional und benötigt keinen Steam-API-Key.
- Steam-Antworten, App-IDs, Bilddomains, Bildformate und Dateigrößen werden validiert; Weiterleitungen bei Metadaten- und Bildabrufen werden nicht automatisch verfolgt.
- Alte games.json-Dateien erhalten die neuen Metadatenfelder automatisch, ohne Favoriten, Spielzeit oder vorhandene Cover zu verlieren.

NEU IN 0.3.1
------------
- Direkte EXE-Spielstarts werden während der Laufzeit überwacht; die gemessene Zeit wird alle 15 Sekunden lokal gespeichert.
- Die Detailansicht zeigt die aufsummierte Spielzeit pro Spiel.
- Alte games.json-Dateien erhalten playtime_seconds automatisch mit dem Standardwert 0.
- Die Prozessüberwachung erkennt Spiele anhand ihrer EXE innerhalb des gespeicherten Installationspfads. Spiele, die außerhalb dieses Ordners starten oder deren EXE-Pfad Windows nicht freigibt, können unentdeckt bleiben.
- Die Spielzeitmessung ist eine Näherung der Laufzeit des gestarteten Prozesses, nicht zwingend der tatsächlichen aktiven Spielzeit.

NEU IN 0.3.0
------------
- Automatische Erkennung unterstützt jetzt zusätzlich Xbox-PC-Spiele, GOG und EA app.
- GOG- und EA-Spiele werden über bekannte Windows-Registry-Einträge gesucht.
- Xbox-Spiele werden über Registry-Einträge und konventionelle XboxGames-Installationsordner erkannt.
- Die XboxGames-Suche ist begrenzt: Es werden nur direkte Titelordner und maximal drei Verzeichnisebenen je Titel geprüft.
- Die Erkennung durchsucht weiterhin keine kompletten Festplatten.
- Erkannte Spiele werden mit Plattformquelle und Startziel in die vorhandene Bibliothek übernommen.
- Die bisherige Steam-/Epic-Erkennung bleibt erhalten.

NEU IN 0.2.9
------------
- Spielebibliothek kann zwischen Listen- und Kachelansicht umgeschaltet werden.
- Kachelansicht zeigt große 16:9-Cover, Spielname, Plattform, Kategorie, Favoriten- und Startaktionen.
- Die Kachelspalten passen sich der verfügbaren Fensterbreite an (1 bis 4 Spalten).
- Detailseite unterstützt zusätzlich ein eigenes breites Hintergrundbild pro Spiel.
- Hintergrundbilder werden auf unterstützte Endungen, Dateivorhandensein und maximal 20 MB geprüft.
- Cover-Dateien bleiben auf maximal 12 MB begrenzt; Hintergrundbilder sind auf maximal 20 MB begrenzt.
- Bestehende games.json-Dateien werden automatisch um background_path ergänzt; vorhandene Spiele und Cover bleiben erhalten.

NEU IN 0.2.8
------------
- Die Startseite zeigt jetzt „Weiterspielen“ mit den zuletzt gestarteten Spielen.
- Favoriten erscheinen zusätzlich in einer eigenen horizontalen Kachelreihe.
- Spielkacheln zeigen Cover, Name, Plattform und Kategorie und besitzen eine Starten-Schaltfläche.
- Beide Reihen aktualisieren sich beim Öffnen der Startseite und nach einem Spielstart.
- Die Startseite ist scrollbar und bleibt auch bei größeren Sammlungen bedienbar.
- Die Datenebene bietet sortierte, begrenzte Abfragen für zuletzt gespielte Spiele und Favoriten.
- Die bestehenden Spielelisten und Metadaten werden unverändert weiterverwendet.

NEU IN 0.2.7
------------
- Spiele können ein eigenes lokales Coverbild erhalten. Unterstützt werden PNG, JPG/JPEG, WEBP, BMP und GIF.
- Cover werden als Vorschaubild in der Bibliothek angezeigt.
- Über „Details / Cover“ öffnet sich eine Detailansicht mit Plattform, Kategorie, Installationspfad und letztem Start.
- In der Detailansicht können Cover ausgewählt oder entfernt und Kategorien geändert werden.
- Cover-Dateien werden auf unterstütztes Format, Vorhandensein und maximal 12 MB geprüft. Die Bilddatei bleibt am ausgewählten Speicherort; sie wird nicht kopiert.
- Bestehende games.json-Dateien erhalten beim Laden automatisch das neue Feld cover_path.

WEITERHIN IN 0.2.6
------------------
- Spielebibliothek um Kategorien erweitert: Spiele können eigene Kategorien erhalten.
- Filter für alle Spiele, Favoriten und einzelne Kategorien.
- Sortierung nach Name, zuletzt gespielt und zuletzt hinzugefügt.
- Der letzte erfolgreiche Start eines Spiels wird lokal gespeichert und angezeigt.
- Die Bibliothekslogik liegt jetzt separat in game_store.py und kann ohne PySide6 getestet werden.
- Alte games.json-Dateien werden beim Laden um neue Metadaten ergänzt; vorhandene Spiele und Favoriten bleiben erhalten.
- games.json wird atomar geschrieben, damit ein unterbrochener Speichervorgang die Bibliothek nicht leer überschreibt.

WEITERHIN ENTHALTEN
-------------------
- Neue automatische Spieleerkennung für installierte Steam- und Epic-Games-Spiele.
- Steam-Bibliotheken werden über libraryfolders.vdf und appmanifest_*.acf erkannt.
- Epic-Spiele werden über die lokalen .item-Manifeste erkannt.
- Erkannte Spiele werden mit Quelle und Installationspfad in der Bibliothek angezeigt.
- Steam- und Epic-Spiele werden über die jeweilige Launcher-URI gestartet.
- Die Erkennung durchsucht nur bekannte Launcher-Metadatenordner, nicht komplette Festplatten.
- Doppelte Einträge werden anhand Startziel und Installationspfad verhindert.

- Die Profilseite lädt den Anzeigenamen aus public.profiles in Supabase.
- Angemeldete Nutzer können ihren Anzeigenamen (3 bis 32 Zeichen) ändern.
- Profilzugriffe verwenden das persönliche Access-Token und werden durch Supabase Row Level Security begrenzt.
- Abgelaufene Access-Tokens werden beim Profilzugriff einmal über das gespeicherte Refresh-Token erneuert.
- Die SQL-Migration legt fehlende Profilzeilen auch für bereits vorhandene Konten an.

INSTALLATION
------------
1. ZIP vollständig entpacken.
2. start.bat doppelklicken.
3. In der Spielebibliothek „Installierte Spiele erkennen“ auswählen, um Steam-, Epic-, Xbox-, GOG- und EA-Spiele zu suchen.
4. Einzelne EXE- oder LNK-Dateien können weiterhin über „Spiel hinzufügen“ eingetragen werden.
5. Öffne bei einem Spiel „Details / Cover“, um Cover, breites Hintergrundbild, Kategorie und Spieldaten zu verwalten.
6. Bei einem Steam-Spiel kannst du „Steam-Infos + Cover laden“ auswählen. Der Abruf benötigt eine Internetverbindung; andere Plattformen können ihre Metadaten manuell über „Infos bearbeiten“ erhalten.
7. Filter, Sortierung und Listen-/Kachelansicht befinden sich oberhalb der Bibliothek.
8. Für Profilfunktionen müssen Supabase-Zugangsdaten eingerichtet und die SQL-Migration ausgeführt sein.

SUPABASE EINRICHTEN (E-MAIL/PASSWORT UND GOOGLE)
------------------------------------------------
1. Erstelle ein Projekt im Supabase Dashboard: https://supabase.com/dashboard
2. Öffne im Projekt die Projekt-URL und den öffentlichen Publishable Key (Dashboard: Connect bzw. Settings → API Keys).
3. Kopiere .env.example zu .env. Trage ein:

   SUPABASE_URL=https://DEIN-PROJEKT.supabase.co
   SUPABASE_PUBLISHABLE_KEY=sb_publishable_DEIN_KEY

   Bei älteren Projekten kann stattdessen SUPABASE_ANON_KEY verwendet werden.
4. Öffne im Supabase Dashboard den SQL Editor und führe die Migrationen in dieser Reihenfolge aus:
   a) supabase/migrations/20261109000000_create_profiles.sql
   b) supabase/migrations/20261119000000_create_friend_system.sql
   c) supabase/migrations/20261121000000_create_friend_presence.sql
5. Aktiviere unter Authentication → Providers den E-Mail-Provider.
6. Für Google: aktiviere Google unter Authentication → Providers und hinterlege dort die OAuth Client-ID und das Client-Secret aus der Google-Cloud-Konfiguration.
7. Trage in Supabase unter Authentication → URL Configuration als erlaubte Redirect URL exakt ein:

   http://127.0.0.1:8765/auth/callback

8. In der Google-Cloud-Konfiguration muss als autorisierte Weiterleitungs-URI die von Supabase im Google-Provider angezeigte Callback-URL stehen (normalerweise https://DEIN-PROJEKT.supabase.co/auth/v1/callback).
9. Starte den Launcher neu und öffne „Anmelden / Registrieren“.

SICHERHEIT
----------
- Passwörter werden nicht lokal gespeichert. Supabase verarbeitet die Authentifizierung.
- Sitzungs- und Refresh-Tokens liegen im Windows Credential Manager (über keyring).
- Verwende ausschließlich den öffentlichen Publishable-Key bzw. den älteren anon-Key.
- Niemals einen Secret- oder service_role-Key in eine Desktop-App oder .env-Datei des Launchers eintragen.
- Die profiles-Tabelle hat Row Level Security: Nutzer dürfen nur das eigene Profil lesen oder ändern.
- Die Anzeige-Metadaten sind keine Berechtigungsquelle; Rollen und Adminrechte dürfen nicht aus display_name/user_metadata abgeleitet werden.

HINWEISE UND GRENZEN
--------------------
- Ohne echte SUPABASE_URL und SUPABASE_PUBLISHABLE_KEY/SUPABASE_ANON_KEY funktionieren Anmeldung, Registrierung und Online-Profile nicht.
- Die SQL-Migration muss im richtigen Supabase-Projekt ausgeführt werden.
- Die Oberfläche lädt und speichert nun den Anzeigenamen in public.profiles. E-Mail-Adresse und Benutzer-ID sind schreibgeschützt.
- Die automatische Spieleerkennung unterstützt Steam, Epic Games, Xbox PC, GOG und EA app. Bei Xbox können je nach Installationsart und Berechtigungen einzelne Titel nicht automatisch erkannt werden; diese lassen sich weiterhin manuell hinzufügen.
- Automatische Online-Metadaten sind in dieser Version nur für Steam-Spiele mit erkannter App-ID verfügbar. Für andere Stores können Titel, Entwickler, Publisher, Erscheinungsdatum, Genres, Beschreibung und Website manuell eingetragen werden.
- Steam stellt nicht für jedes Spiel ein hochformatiges Bibliothekscover bereit. Wenn kein Cover verfügbar ist, bleibt das vorhandene Cover unverändert und kann manuell ausgewählt werden.
- Der Steam-Store-Endpunkt kann zeitweise drosseln oder einzelne App-Details nicht liefern. In diesem Fall bleiben manuelle Metadaten und lokale Cover weiterhin nutzbar.
- Google OAuth kann erst nach Einrichtung der Google-Zugangsdaten im Supabase-Dashboard getestet werden.
- Die bestehende Zugangsauswahl wurde in diesem Entwicklungsschritt nicht verändert.

ENTWICKLERTESTS
---------------
Im Projektordner ausführen:

   python -m unittest -v tests_game_detection tests_game_store tests_game_metadata tests_process_monitor tests_auth_config tests_friend_service tests_presence_service

Für die Spielzeitmessung: Ein erkanntes Spiel starten, mindestens 30 Sekunden laufen lassen,
das Spiel schließen und anschließend in der Detailansicht „Gesamte Spielzeit“ prüfen. Die Erkennung fragt alle 15 Sekunden ab; kurze Sitzungen können deshalb ungenau sein.

Die Tests prüfen tägliche und wöchentliche Spielzeitstatistiken, Legacy-Migration, Steam-/Epic-/Xbox-/GOG-/EA-Erkennung, Metadaten-Normalisierung und -Validierung, simulierte Steam-API-Antworten, Cover-Downloadgrenzen sowie Hinzufügen, Duplikatprüfung, Kategorien, Favoriten, Spielzeit, Cover-Pfade, Dashboard-Abfragen, die Migration älterer games.json-Dateien und die neue Prozesspfad-Zuordnung. Sie verwenden simulierte HTTP-Antworten und temporäre Testordner; ein echter Steam-Onlineabruf und die Windows-GUI werden damit nicht getestet.


FREUNDESYSTEM – ENTWICKLERHINWEIS
---------------------------------
Die neue Freundesdatenebene ist in friend_service.py enthalten. Vor der Nutzung müssen beide
SQL-Migrationen im selben Supabase-Projekt ausgeführt sein: zuerst profiles, danach
create_friend_system.sql. Die neue API stellt folgende Methoden bereit:
- search_players(query, limit=10)
- send_friend_request(target_user_id)
- list_requests() und list_friends()
- respond_to_request(request_id, accept=True/False)
- cancel_request(request_id)

Die Freundesoberfläche ist in 0.4.2 noch nicht eingebaut. Suche und Aktionen sind zunächst
als testbare Datenebene vorbereitet. Ein echter Supabase-Online-Test benötigt ein eingerichtetes
Projekt und zwei Testkonten; die automatisierten Tests simulieren HTTP-Antworten.

FREUNDESSEITE – 0.4.3
-----------------------
Die Seite „Freunde“ befindet sich in der Hauptnavigation. Mit einem angemeldeten Supabase-Konto
kann nach Anzeigenamen gesucht, eine Anfrage gesendet, eingehende Anfragen angenommen/abgelehnt
und ausgehende Anfragen zurückgezogen werden. Die Freundesliste zeigt zunächst Initialen als
Avatar-Platzhalter. Live-Online-Status und Profilbilder sind noch nicht angebunden.
Voraussetzung: Die Profil-Migration und anschließend die Freundesystem-Migration aus dem Ordner
supabase/migrations müssen im Supabase SQL Editor ausgeführt worden sein.

ONLINE-STATUS / PRESENCE (0.4.4)
-------------------------------
Führe die zusätzliche Migration 20261121000000_create_friend_presence.sql nach den
Profil- und Freundes-Migrationen aus (siehe Einrichtungsreihenfolge). Die App sendet für angemeldete Nutzer alle 60 Sekunden
einen Heartbeat. Ein Nutzer gilt online, solange sein letzter Heartbeat höchstens 3 Minuten alt
ist. Gäste werden nicht erfasst. Beim Abmelden wird der Status entfernt. Die Presence-RPCs
zeigen nur die angenommenen Freunde und erlauben keine direkte Tabellenabfrage.

Automatisierte Presence-Tests laufen mit:
   python -m unittest -v tests_presence_service
Ein Live-Test benötigt das Supabase-Projekt und die neue SQL-Migration.
