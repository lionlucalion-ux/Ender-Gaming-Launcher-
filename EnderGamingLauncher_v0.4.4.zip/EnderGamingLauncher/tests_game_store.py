from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path

from game_store import DEFAULT_CATEGORY, GameStore


class GameStoreTests(unittest.TestCase):
    def test_add_manual_game_and_prevent_duplicate(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = GameStore(Path(tmp) / "games.json")
            game_path = Path(tmp) / "ExampleGame.exe"
            store.add(str(game_path))
            self.assertEqual(len(store.games), 1)
            self.assertEqual(store.games[0]["name"], "ExampleGame")
            self.assertEqual(store.games[0]["category"], DEFAULT_CATEGORY)
            self.assertTrue(store.games[0]["added_at"])
            with self.assertRaises(ValueError):
                store.add(str(game_path))

    def test_add_detected_game_prevents_duplicate_target(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = GameStore(Path(tmp) / "games.json")
            detected = {
                "name": "Sample Steam Game",
                "path": str(Path(tmp) / "Sample"),
                "launch_target": "steam://rungameid/123",
                "source": "Steam",
                "app_id": "123",
            }
            self.assertTrue(store.add_detected(detected))
            self.assertFalse(store.add_detected({**detected, "path": str(Path(tmp) / "Other")}))
            self.assertEqual(len(store.games), 1)
            self.assertEqual(store.games[0]["app_id"], "123")

    def test_rescan_enriches_existing_steam_entry_with_app_id(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = GameStore(Path(tmp) / "games.json")
            detected = {
                "name": "Existing Steam Game", "path": str(Path(tmp) / "Game"),
                "launch_target": "steam://rungameid/456", "source": "Steam",
            }
            self.assertTrue(store.add_detected(detected))
            self.assertFalse(store.add_detected({**detected, "app_id": "456"}))
            self.assertEqual(store.games[0]["app_id"], "456")

    def test_category_favorite_and_played_timestamp_persist(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "games.json"
            store = GameStore(path)
            store.add_detected({
                "name": "Sample", "path": str(Path(tmp) / "Sample"),
                "launch_target": "steam://rungameid/321", "source": "Steam",
            })
            game_id = store.games[0]["id"]
            store.set_category(game_id, "Action & Adventure")
            store.toggle_favorite(game_id)
            store.mark_played(game_id)

            reloaded = GameStore(path)
            game = reloaded.games[0]
            self.assertEqual(game["category"], "Action & Adventure")
            self.assertTrue(game["favorite"])
            self.assertTrue(game["last_played_at"])

    def test_playtime_is_added_and_persisted(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "games.json"
            store = GameStore(path)
            store.add(str(Path(tmp) / "TrackedGame.exe"))
            game_id = store.games[0]["id"]
            store.add_playtime(game_id, 3665)
            reloaded = GameStore(path)
            self.assertEqual(reloaded.games[0]["playtime_seconds"], 3665)

    def test_daily_playtime_stats_persist_and_rank_games(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "games.json"
            store = GameStore(path)
            store.add(str(Path(tmp) / "First.exe"))
            first_id = store.games[0]["id"]
            store.add(str(Path(tmp) / "Second.exe"))
            second_id = store.games[1]["id"]
            store.add_playtime(first_id, 1800)
            store.add_playtime(second_id, 3600)
            reloaded = GameStore(path)
            stats = reloaded.get_playtime_stats()
            self.assertEqual(stats["total_seconds"], 5400)
            self.assertEqual(stats["today_seconds"], 5400)
            self.assertEqual(stats["week_seconds"], 5400)
            self.assertEqual(stats["top_games"][0]["id"], second_id)

    def test_legacy_library_migrates_daily_playtime(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "games.json"
            path.write_text(json.dumps([{"id": "legacy", "name": "Old", "playtime_seconds": 42}]))
            store = GameStore(path)
            self.assertEqual(store.games[0]["daily_playtime"], {})
            self.assertEqual(store.games[0]["playtime_seconds"], 42)

    def test_playtime_rejects_invalid_and_ignores_zero(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = GameStore(Path(tmp) / "games.json")
            store.add(str(Path(tmp) / "TrackedGame.exe"))
            game_id = store.games[0]["id"]
            store.add_playtime(game_id, 0)
            self.assertEqual(store.games[0]["playtime_seconds"], 0)
            with self.assertRaises(ValueError):
                store.add_playtime(game_id, "invalid")

    def test_category_length_is_validated(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = GameStore(Path(tmp) / "games.json")
            store.add_detected({
                "name": "Sample", "path": str(Path(tmp) / "Sample"),
                "launch_target": "steam://rungameid/555", "source": "Steam",
            })
            with self.assertRaises(ValueError):
                store.set_category(store.games[0]["id"], "x" * 33)

    def test_cover_path_is_saved_and_can_be_removed(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            image = root / "sample-cover.png"
            image.write_bytes(b"test-image-data")
            library = root / "games.json"
            store = GameStore(library)
            store.add(str(root / "SampleGame.exe"))
            game_id = store.games[0]["id"]

            store.set_cover_path(game_id, str(image))
            reloaded = GameStore(library)
            self.assertEqual(reloaded.games[0]["cover_path"], str(image.resolve()))

            reloaded.clear_cover_path(game_id)
            self.assertEqual(GameStore(library).games[0]["cover_path"], "")

    def test_cover_validation_rejects_missing_or_unsupported_files(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            store = GameStore(root / "games.json")
            store.add(str(root / "SampleGame.exe"))
            game_id = store.games[0]["id"]
            unsupported = root / "cover.txt"
            unsupported.write_text("not an image", encoding="utf-8")
            with self.assertRaises(ValueError):
                store.set_cover_path(game_id, str(unsupported))
            with self.assertRaises(ValueError):
                store.set_cover_path(game_id, str(root / "missing.png"))

    def test_background_path_is_saved_and_can_be_removed(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            image = root / "sample-background.jpg"
            image.write_bytes(b"test-background-data")
            library = root / "games.json"
            store = GameStore(library)
            store.add(str(root / "SampleGame.exe"))
            game_id = store.games[0]["id"]

            store.set_background_path(game_id, str(image))
            reloaded = GameStore(library)
            self.assertEqual(reloaded.games[0]["background_path"], str(image.resolve()))

            reloaded.clear_background_path(game_id)
            self.assertEqual(GameStore(library).games[0]["background_path"], "")

    def test_background_validation_rejects_missing_or_unsupported_files(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            store = GameStore(root / "games.json")
            store.add(str(root / "SampleGame.exe"))
            game_id = store.games[0]["id"]
            unsupported = root / "background.txt"
            unsupported.write_text("not an image", encoding="utf-8")
            with self.assertRaises(ValueError):
                store.set_background_path(game_id, str(unsupported))
            with self.assertRaises(ValueError):
                store.set_background_path(game_id, str(root / "missing.jpg"))

    def test_background_size_limit_is_enforced(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            oversized = root / "large-background.png"
            with oversized.open("wb") as handle:
                handle.truncate(20 * 1024 * 1024 + 1)
            store = GameStore(root / "games.json")
            store.add(str(root / "SampleGame.exe"))
            with self.assertRaisesRegex(ValueError, "20 MB"):
                store.set_background_path(store.games[0]["id"], str(oversized))

    def test_dashboard_recent_games_are_newest_first_and_exclude_unplayed(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = GameStore(Path(tmp) / "games.json")
            for name in ("Older", "Never Played", "Newest"):
                store.add(str(Path(tmp) / f"{name}.exe"))
            by_name = {game["name"]: game["id"] for game in store.games}
            for game in store.games:
                if game["name"] == "Older":
                    game["last_played_at"] = "2026-11-10T12:00:00+00:00"
                elif game["name"] == "Newest":
                    game["last_played_at"] = "2026-11-13T12:00:00+00:00"
            store.save()

            recent = store.get_recently_played(5)
            self.assertEqual([game["name"] for game in recent], ["Newest", "Older"])
            self.assertEqual(store.get_recently_played(1)[0]["id"], by_name["Newest"])
            self.assertEqual(store.get_recently_played(0), [])

    def test_dashboard_favorites_are_alphabetical_and_limited(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = GameStore(Path(tmp) / "games.json")
            for name in ("Zeta", "Alpha", "Beta"):
                store.add(str(Path(tmp) / f"{name}.exe"))
            for game in store.games:
                game["favorite"] = game["name"] != "Beta"
            store.save()

            self.assertEqual([g["name"] for g in store.get_favorites(5)], ["Alpha", "Zeta"])
            self.assertEqual([g["name"] for g in store.get_favorites(1)], ["Alpha"])
            self.assertEqual(store.get_favorites(0), [])

    def test_legacy_library_is_migrated_without_losing_favorite(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "games.json"
            path.write_text(json.dumps([{
                "id": "legacy-id", "name": "Old Game", "path": "C:/Games/Old.exe",
                "launch_target": "", "source": "Manuell", "favorite": True,
            }]), encoding="utf-8")
            store = GameStore(path)
            self.assertEqual(len(store.games), 1)
            self.assertTrue(store.games[0]["favorite"])
            self.assertEqual(store.games[0]["category"], DEFAULT_CATEGORY)
            saved = json.loads(path.read_text(encoding="utf-8"))
            self.assertIn("last_played_at", saved[0])
            self.assertEqual(saved[0]["cover_path"], "")
            self.assertEqual(saved[0]["background_path"], "")

    def test_legacy_steam_launch_target_migrates_app_id_and_metadata_fields(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "games.json"
            path.write_text(json.dumps([{
                "id": "legacy-steam", "name": "Old Steam Game", "path": "C:/Games/Old",
                "launch_target": "steam://rungameid/570", "source": "Steam", "favorite": True,
            }]), encoding="utf-8")
            store = GameStore(path)
            self.assertEqual(store.games[0]["app_id"], "570")
            self.assertEqual(store.games[0]["genres"], [])
            self.assertEqual(store.games[0]["description"], "")
            self.assertTrue(store.games[0]["favorite"])

    def test_manual_metadata_is_saved_and_validated(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "games.json"
            store = GameStore(path)
            store.add(str(Path(tmp) / "Example.exe"))
            game_id = store.games[0]["id"]
            store.set_metadata(game_id, {
                "developer": "Studio One", "publisher": "Publisher",
                "release_date": "2024", "genres": "Action, Adventure",
                "description": "A sample game", "website": "https://example.com",
                "metadata_source": "Manuell bearbeitet",
            })
            saved = GameStore(path).games[0]
            self.assertEqual(saved["developer"], "Studio One")
            self.assertEqual(saved["genres"], ["Action", "Adventure"])
            self.assertEqual(saved["website"], "https://example.com")
            with self.assertRaisesRegex(ValueError, "HTTP- oder HTTPS"):
                store.set_metadata(game_id, {"website": "javascript:alert(1)"})

    def test_metadata_fields_are_bounded(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = GameStore(Path(tmp) / "games.json")
            store.add(str(Path(tmp) / "Example.exe"))
            game_id = store.games[0]["id"]
            store.set_metadata(game_id, {"developer": "D" * 500, "description": "X" * 5000,
                                         "genres": [str(i) for i in range(20)]})
            game = store.games[0]
            self.assertEqual(len(game["developer"]), 200)
            self.assertEqual(len(game["description"]), 4000)
            self.assertEqual(len(game["genres"]), 12)


if __name__ == "__main__":
    unittest.main()
