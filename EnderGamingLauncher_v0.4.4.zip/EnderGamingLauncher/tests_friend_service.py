import unittest
from unittest.mock import Mock, patch
from uuid import UUID

import requests

from friend_service import FriendError, FriendService


class FakeResponse:
    def __init__(self, status_code=200, data=None):
        self.status_code = status_code
        self._data = data

    def json(self):
        if isinstance(self._data, Exception):
            raise self._data
        return self._data


class FakeAuth:
    configured = True
    project_url = "https://example.supabase.co"

    def __init__(self):
        self.refresh_count = 0
        self.header_count = 0

    def get_session_headers(self):
        self.header_count += 1
        return {
            "apikey": "sb_publishable_testkey12345678",
            "Authorization": f"Bearer token-{self.header_count}",
        }

    def restore_session(self):
        self.refresh_count += 1
        return {"id": "user"}


class FriendServiceTests(unittest.TestCase):
    def setUp(self):
        self.auth = FakeAuth()
        self.service = FriendService(self.auth)

    def test_search_validates_query_before_network(self):
        with patch("friend_service.requests.post") as post:
            with self.assertRaises(FriendError):
                self.service.search_players("ab")
            post.assert_not_called()

    def test_search_sends_bounded_query_and_returns_rows(self):
        rows = [{"player_id": "11111111-1111-4111-8111-111111111111", "display_name": "Ender"}]
        with patch("friend_service.requests.post", return_value=FakeResponse(200, rows)) as post:
            result = self.service.search_players("  End  ", limit=100)
        self.assertEqual(result, rows)
        args, kwargs = post.call_args
        self.assertTrue(args[0].endswith("/rpc/search_players"))
        self.assertEqual(kwargs["json"], {"search_query": "End", "result_limit": 20})
        self.assertFalse(kwargs["allow_redirects"])

    def test_send_request_validates_uuid(self):
        with patch("friend_service.requests.post") as post:
            with self.assertRaises(FriendError):
                self.service.send_friend_request("not-a-uuid")
            post.assert_not_called()

    def test_send_request_returns_request_id(self):
        request_id = "22222222-2222-4222-8222-222222222222"
        with patch("friend_service.requests.post", return_value=FakeResponse(200, request_id)):
            self.assertEqual(self.service.send_friend_request(
                "11111111-1111-4111-8111-111111111111"
            ), request_id)

    def test_accept_request_calls_scoped_rpc(self):
        request_id = "22222222-2222-4222-8222-222222222222"
        with patch("friend_service.requests.post", return_value=FakeResponse(200, True)) as post:
            self.assertTrue(self.service.respond_to_request(request_id, True))
        self.assertEqual(post.call_args.kwargs["json"], {
            "request_id": request_id, "accept_request": True
        })

    def test_lists_return_empty_on_null_and_reject_bad_shapes(self):
        with patch("friend_service.requests.post", return_value=FakeResponse(200, None)):
            self.assertEqual(self.service.list_friends(), [])
        with patch("friend_service.requests.post", return_value=FakeResponse(200, {"oops": 1})):
            with self.assertRaises(FriendError):
                self.service.list_requests()

    def test_401_refreshes_once_and_retries(self):
        request_id = "22222222-2222-4222-8222-222222222222"
        with patch(
            "friend_service.requests.post",
            side_effect=[
                FakeResponse(401, {"message": "expired"}),
                FakeResponse(200, request_id),
            ],
        ) as post:
            self.assertEqual(self.service.send_friend_request(
                "11111111-1111-4111-8111-111111111111"
            ), request_id)
        self.assertEqual(self.auth.refresh_count, 1)
        self.assertEqual(post.call_count, 2)

    def test_http_errors_become_friendly_errors(self):
        with patch("friend_service.requests.post", return_value=FakeResponse(404, {"message": "missing migration"})):
            with self.assertRaisesRegex(FriendError, "missing migration"):
                self.service.list_friends()

    def test_network_errors_are_wrapped(self):
        with patch("friend_service.requests.post", side_effect=requests.Timeout("offline")):
            with self.assertRaisesRegex(FriendError, "Verbindung"):
                self.service.list_friends()


if __name__ == "__main__":
    unittest.main()
