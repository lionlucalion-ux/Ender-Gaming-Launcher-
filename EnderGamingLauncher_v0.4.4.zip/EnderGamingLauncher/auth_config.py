"""Validation helpers for public Supabase desktop-app configuration."""
from __future__ import annotations

import base64
import json
from urllib.parse import urlparse


def is_valid_supabase_url(value: str) -> bool:
    value = (value or "").strip().rstrip("/")
    try:
        parsed = urlparse(value)
    except ValueError:
        return False
    return (
        parsed.scheme == "https"
        and bool(parsed.hostname)
        and parsed.hostname.endswith(".supabase.co")
        and parsed.username is None
        and parsed.password is None
        and parsed.port is None
        and parsed.path in ("", "/")
        and not parsed.query
        and not parsed.fragment
        and "DEIN-PROJEKT" not in value.upper()
        and "YOUR_PROJECT" not in value.upper()
    )


def is_public_supabase_key(value: str) -> bool:
    """Accept publishable keys and legacy anon JWTs; reject secret/service-role keys."""
    key = (value or "").strip()
    if not key or any(marker in key.upper() for marker in (
        "DEIN_SUPABASE", "PUBLISHABLE_ODER", "REPLACE_ME", "YOUR_KEY",
    )):
        return False

    if key.startswith("sb_publishable_"):
        return len(key.removeprefix("sb_publishable_")) >= 8

    # Legacy Supabase anon keys are JWTs with role=anon. Never accept service_role.
    parts = key.split(".")
    if len(parts) != 3:
        return False
    try:
        payload_part = parts[1]
        payload_part += "=" * (-len(payload_part) % 4)
        payload = json.loads(base64.urlsafe_b64decode(payload_part.encode("ascii")))
    except (ValueError, UnicodeError, json.JSONDecodeError):
        return False
    return isinstance(payload, dict) and payload.get("role") == "anon" and payload.get("iss") == "supabase"


def is_supabase_configured(url: str, key: str) -> bool:
    return is_valid_supabase_url(url) and is_public_supabase_key(key)
