"""Persistent local game-library storage for Ender Gaming Launcher.

Only game metadata is stored here. Authentication credentials and passwords are
handled separately by the authentication service and Windows Credential Manager.
"""
from __future__ import annotations

import json
import os
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from uuid import uuid4

from platformdirs import user_data_dir


DEFAULT_CATEGORY = "Nicht kategorisiert"
MAX_CATEGORY_LENGTH = 32
MAX_COVER_SIZE_BYTES = 12 * 1024 * 1024
ALLOWED_COVER_SUFFIXES = {".png", ".jpg", ".jpeg", ".webp", ".bmp", ".gif"}


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


class GameStore:
    """Read and write the user's local game library without storing secrets."""

    def __init__(self, storage_path: Path | str | None = None) -> None:
        if storage_path is None:
            folder = Path(user_data_dir("EnderGamingLauncher", "EndersStudios"))
            folder.mkdir(parents=True, exist_ok=True)
            storage_path = folder / "games.json"
        self.path = Path(storage_path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.games: list[dict[str, Any]] = []
        self.load()

    def load(self) -> None:
        try:
            raw = json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            self.games = []
            return

        if not isinstance(raw, list):
            self.games = []
            return

        normalized: list[dict[str, Any]] = []
        changed = False
        for item in raw:
            if not isinstance(item, dict):
                changed = True
                continue
            game = dict(item)
            defaults = {
                "id": str(uuid4()),
                "name": "Unbekanntes Spiel",
                "path": "",
                "launch_target": "",
                "source": "Manuell",
                "favorite": False,
                "category": DEFAULT_CATEGORY,
                "added_at": "",
                "last_played_at": "",
                "playtime_seconds": 0,
                "daily_playtime": {},
                "cover_path": "",
                "background_path": "",
                "app_id": "",
                "metadata_title": "",
                "developer": "",
                "publisher": "",
                "release_date": "",
                "genres": [],
                "description": "",
                "website": "",
                "header_image_url": "",
                "metadata_source": "",
                "metadata_updated_at": "",
            }
            for key, value in defaults.items():
                if key not in game:
                    game[key] = value
                    changed = True
            game["favorite"] = bool(game.get("favorite"))
            raw_daily = game.get("daily_playtime", {})
            if not isinstance(raw_daily, dict):
                raw_daily = {}
                changed = True
            daily = {}
            for day, seconds in raw_daily.items():
                try:
                    # Keep only ISO calendar dates and bounded, non-negative durations.
                    datetime.strptime(str(day), "%Y-%m-%d")
                    daily[str(day)] = max(0, min(int(seconds), 24 * 60 * 60))
                except (TypeError, ValueError):
                    changed = True
            if daily != game.get("daily_playtime", {}):
                changed = True
            game["daily_playtime"] = daily
            try:
                game["playtime_seconds"] = max(0, int(game.get("playtime_seconds", 0)))
            except (TypeError, ValueError):
                game["playtime_seconds"] = 0
                changed = True
            game["category"] = str(game.get("category") or DEFAULT_CATEGORY).strip()[:MAX_CATEGORY_LENGTH]
            if not game["category"]:
                game["category"] = DEFAULT_CATEGORY
            raw_app_id = game.get("app_id")
            app_id = str(raw_app_id or "").strip()
            if not app_id:
                match = re.fullmatch(r"steam://rungameid/([0-9]{1,12})", str(game.get("launch_target") or "").strip(), re.IGNORECASE)
                if match:
                    app_id = match.group(1)
                    changed = True
            game["app_id"] = app_id if app_id.isdigit() and len(app_id) <= 12 else ""
            if game["app_id"] != raw_app_id:
                changed = True
            raw_genres = game.get("genres", [])
            if isinstance(raw_genres, str):
                raw_genres = [part.strip() for part in raw_genres.split(",")]
            if not isinstance(raw_genres, list):
                raw_genres = []
            game["genres"] = [str(value).strip()[:40] for value in raw_genres if str(value).strip()][:12]
            if game["genres"] != item.get("genres", []):
                changed = True
            for field, limit in (("metadata_title", 200), ("developer", 200), ("publisher", 200),
                                 ("release_date", 100), ("description", 4000), ("website", 300),
                                 ("header_image_url", 1000), ("metadata_source", 40),
                                 ("metadata_updated_at", 40)):
                original = game.get(field)
                game[field] = str(original or "")[:limit]
                if game[field] != original:
                    changed = True
            normalized.append(game)

        self.games = normalized
        if changed:
            self.save()

    def save(self) -> None:
        """Write atomically so an interrupted write cannot truncate games.json."""
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.path.with_suffix(self.path.suffix + ".tmp")
        temporary.write_text(
            json.dumps(self.games, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        temporary.replace(self.path)

    @staticmethod
    def _normal_path(value: str) -> str:
        return os.path.normcase(os.path.normpath(str(value))).casefold()

    def add(self, executable: str) -> None:
        path = Path(executable)
        normalized = self._normal_path(str(path))
        if any(self._normal_path(g.get("path", "")) == normalized for g in self.games):
            raise ValueError("Dieses Spiel ist bereits in deiner Bibliothek.")
        self.games.append({
            "id": str(uuid4()),
            "name": path.stem.replace("_", " "),
            "path": str(path),
            "launch_target": "",
            "source": "Manuell",
            "favorite": False,
            "category": DEFAULT_CATEGORY,
            "added_at": _utc_now(),
            "last_played_at": "",
            "playtime_seconds": 0,
            "app_id": "",
            "metadata_title": "",
            "developer": "",
            "publisher": "",
            "release_date": "",
            "genres": [],
            "description": "",
            "website": "",
            "header_image_url": "",
            "metadata_source": "",
            "metadata_updated_at": "",
        })
        self.save()

    def add_detected(self, detected: dict) -> bool:
        """Add one discovered game; return False if it is already in the library."""
        name = str(detected.get("name") or "Unbekanntes Spiel").strip()
        path = str(detected.get("path") or "").strip()
        launch_target = str(detected.get("launch_target") or "").strip()
        if not name or not path or not launch_target:
            return False
        target_key = launch_target.casefold()
        path_key = self._normal_path(path)
        for game in self.games:
            existing_target = str(game.get("launch_target") or "").casefold()
            existing_path = self._normal_path(str(game.get("path") or ""))
            if (existing_target and existing_target == target_key) or existing_path == path_key:
                detected_app_id = str(detected.get("app_id") or "").strip()
                if detected_app_id.isdigit() and not str(game.get("app_id") or ""):
                    game["app_id"] = detected_app_id
                    self.save()
                return False
        self.games.append({
            "id": str(uuid4()),
            "name": name,
            "path": path,
            "launch_target": launch_target,
            "source": str(detected.get("source") or "Automatisch erkannt"),
            "favorite": False,
            "category": DEFAULT_CATEGORY,
            "added_at": _utc_now(),
            "last_played_at": "",
            "playtime_seconds": 0,
            "app_id": str(detected.get("app_id") or "") if str(detected.get("app_id") or "").isdigit() and len(str(detected.get("app_id") or "")) <= 12 else "",
            "metadata_title": "",
            "developer": "",
            "publisher": "",
            "release_date": "",
            "genres": [],
            "description": "",
            "website": "",
            "header_image_url": "",
            "metadata_source": "",
            "metadata_updated_at": "",
        })
        self.save()
        return True

    def remove(self, game_id: str) -> None:
        self.games = [game for game in self.games if game.get("id") != game_id]
        self.save()

    def toggle_favorite(self, game_id: str) -> None:
        for game in self.games:
            if game.get("id") == game_id:
                game["favorite"] = not bool(game.get("favorite"))
                break
        self.save()

    def set_category(self, game_id: str, category: str) -> None:
        value = " ".join(str(category).split())
        if len(value) > MAX_CATEGORY_LENGTH:
            raise ValueError(f"Kategorien dürfen höchstens {MAX_CATEGORY_LENGTH} Zeichen lang sein.")
        if not value:
            value = DEFAULT_CATEGORY
        for game in self.games:
            if game.get("id") == game_id:
                game["category"] = value
                break
        self.save()

    def set_cover_path(self, game_id: str, cover_path: str) -> None:
        """Associate a local image with a game; the image itself is not copied."""
        candidate = Path(str(cover_path)).expanduser()
        if candidate.suffix.casefold() not in ALLOWED_COVER_SUFFIXES:
            raise ValueError("Bitte wähle ein Bild im PNG-, JPG-, WEBP-, BMP- oder GIF-Format.")
        if not candidate.is_file():
            raise ValueError("Die ausgewählte Cover-Datei wurde nicht gefunden.")
        try:
            size = candidate.stat().st_size
        except OSError as exc:
            raise ValueError("Die Cover-Datei kann nicht gelesen werden.") from exc
        if size > MAX_COVER_SIZE_BYTES:
            raise ValueError("Das Cover ist zu groß. Erlaubt sind höchstens 12 MB.")

        for game in self.games:
            if game.get("id") == game_id:
                game["cover_path"] = str(candidate.resolve())
                self.save()
                return
        raise ValueError("Das Spiel wurde in deiner Bibliothek nicht gefunden.")

    def clear_cover_path(self, game_id: str) -> None:
        for game in self.games:
            if game.get("id") == game_id:
                game["cover_path"] = ""
                self.save()
                return
        raise ValueError("Das Spiel wurde in deiner Bibliothek nicht gefunden.")

    def set_background_path(self, game_id: str, background_path: str) -> None:
        """Associate a local wide background image with a game."""
        candidate = Path(str(background_path)).expanduser()
        if candidate.suffix.casefold() not in ALLOWED_COVER_SUFFIXES:
            raise ValueError("Bitte wähle ein Bild im PNG-, JPG-, WEBP-, BMP- oder GIF-Format.")
        if not candidate.is_file():
            raise ValueError("Die ausgewählte Hintergrunddatei wurde nicht gefunden.")
        try:
            size = candidate.stat().st_size
        except OSError as exc:
            raise ValueError("Die Hintergrunddatei kann nicht gelesen werden.") from exc
        if size > 20 * 1024 * 1024:
            raise ValueError("Das Hintergrundbild ist zu groß. Erlaubt sind höchstens 20 MB.")

        for game in self.games:
            if game.get("id") == game_id:
                game["background_path"] = str(candidate.resolve())
                self.save()
                return
        raise ValueError("Das Spiel wurde in deiner Bibliothek nicht gefunden.")

    def clear_background_path(self, game_id: str) -> None:
        for game in self.games:
            if game.get("id") == game_id:
                game["background_path"] = ""
                self.save()
                return
        raise ValueError("Das Spiel wurde in deiner Bibliothek nicht gefunden.")

    def set_metadata(self, game_id: str, metadata: dict[str, Any]) -> None:
        """Validate and persist public/manual descriptive metadata for one game."""
        from urllib.parse import urlparse

        allowed_limits = {
            "metadata_title": 200, "developer": 200, "publisher": 200,
            "release_date": 100, "description": 4000, "website": 300,
            "header_image_url": 1000, "metadata_source": 40,
            "metadata_updated_at": 40,
        }
        clean: dict[str, Any] = {}
        for field, limit in allowed_limits.items():
            if field in metadata:
                clean[field] = " ".join(str(metadata.get(field) or "").split())[:limit]
        if "genres" in metadata:
            raw_genres = metadata.get("genres")
            if isinstance(raw_genres, str):
                raw_genres = raw_genres.split(",")
            if not isinstance(raw_genres, (list, tuple)):
                raise ValueError("Genres müssen als Liste oder kommaseparierter Text angegeben werden.")
            genres = []
            for item in raw_genres:
                value = " ".join(str(item or "").split())[:40]
                if value and value not in genres:
                    genres.append(value)
                if len(genres) >= 12:
                    break
            clean["genres"] = genres
        website = clean.get("website", "")
        if website:
            try:
                parsed = urlparse(website)
                if parsed.scheme not in {"http", "https"} or not parsed.hostname or parsed.username or parsed.password:
                    raise ValueError
            except ValueError as exc:
                raise ValueError("Die Website muss eine gültige HTTP- oder HTTPS-Adresse sein.") from exc
        header_url = clean.get("header_image_url", "")
        if header_url:
            try:
                parsed = urlparse(header_url)
                host = (parsed.hostname or "").casefold()
                if parsed.scheme != "https" or not (host == "steamstatic.com" or host.endswith(".steamstatic.com") or host == "akamaihd.net" or host.endswith(".akamaihd.net")):
                    raise ValueError
            except ValueError as exc:
                raise ValueError("Die Bildadresse muss von einer sicheren Steam-Bilddomain stammen.") from exc
        for game in self.games:
            if game.get("id") == game_id:
                game.update(clean)
                self.save()
                return
        raise ValueError("Das Spiel wurde in deiner Bibliothek nicht gefunden.")

    def get_playtime_stats(self, today=None) -> dict[str, Any]:
        """Return local playtime totals and a sorted top-games list."""
        from datetime import date, timedelta
        current = today or datetime.now().astimezone().date()
        week_start = current - timedelta(days=current.weekday())
        total = 0
        today_total = 0
        week_total = 0
        ranked = []
        for game in self.games:
            seconds = max(0, int(game.get("playtime_seconds", 0) or 0))
            daily = game.get("daily_playtime", {})
            if not isinstance(daily, dict):
                daily = {}
            game_today = max(0, int(daily.get(current.isoformat(), 0) or 0))
            game_week = 0
            for offset in range(7):
                day = (week_start + timedelta(days=offset)).isoformat()
                try:
                    game_week += max(0, int(daily.get(day, 0) or 0))
                except (TypeError, ValueError):
                    continue
            total += seconds
            today_total += game_today
            week_total += game_week
            if seconds:
                ranked.append({"id": game.get("id"), "name": game.get("name", "Spiel"), "seconds": seconds})
        ranked.sort(key=lambda item: (-item["seconds"], str(item["name"]).casefold()))
        return {"total_seconds": total, "today_seconds": today_total,
                "week_seconds": week_total, "top_games": ranked[:5]}

    def get_recently_played(self, limit: int = 5) -> list[dict[str, Any]]:
        """Return games with a play timestamp, newest first."""
        try:
            count = max(0, int(limit))
        except (TypeError, ValueError):
            count = 5
        if count == 0:
            return []
        played = [game for game in self.games if str(game.get("last_played_at") or "").strip()]
        played.sort(key=lambda game: str(game.get("last_played_at") or ""), reverse=True)
        return [dict(game) for game in played[:count]]

    def get_favorites(self, limit: int = 5) -> list[dict[str, Any]]:
        """Return favorite games in a stable, user-friendly name order."""
        try:
            count = max(0, int(limit))
        except (TypeError, ValueError):
            count = 5
        if count == 0:
            return []
        favorites = [game for game in self.games if bool(game.get("favorite"))]
        favorites.sort(key=lambda game: str(game.get("name") or "").casefold())
        return [dict(game) for game in favorites[:count]]

    def mark_played(self, game_id: str) -> None:
        for game in self.games:
            if game.get("id") == game_id:
                game["last_played_at"] = _utc_now()
                break
        self.save()

    def add_playtime(self, game_id: str, seconds: int) -> None:
        """Add a verified foreground launcher-process duration to a game."""
        try:
            amount = max(0, min(int(seconds), 24 * 60 * 60))
        except (TypeError, ValueError):
            raise ValueError("Die Spielzeit muss eine gültige Sekundenanzahl sein.")
        if amount == 0:
            return
        for game in self.games:
            if game.get("id") == game_id:
                current = max(0, int(game.get("playtime_seconds", 0) or 0))
                game["playtime_seconds"] = current + amount
                today = datetime.now().astimezone().date().isoformat()
                daily = game.setdefault("daily_playtime", {})
                daily[today] = max(0, int(daily.get(today, 0) or 0)) + amount
                self.save()
                return
        raise ValueError("Das Spiel wurde in deiner Bibliothek nicht gefunden.")
