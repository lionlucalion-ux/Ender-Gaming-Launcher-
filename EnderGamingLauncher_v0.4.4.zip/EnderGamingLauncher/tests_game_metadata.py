from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from game_metadata import MetadataError, download_steam_cover, fetch_steam_metadata, parse_steam_appdetails


class FakeResponse:
    def __init__(self, payload=None, content=b"", *, ok=True, headers=None):
        self.ok = ok
        self.status_code = 200 if ok else 503
        self._payload = payload
        self.content = content
        self.headers = headers or {}

    def json(self):
        return self._payload

    def iter_content(self, chunk_size):
        for start in range(0, len(self.content), chunk_size):
            yield self.content[start:start + chunk_size]


class GameMetadataTests(unittest.TestCase):
    def setUp(self):
        self.payload = {
            "570": {
                "success": True,
                "data": {
                    "name": "Example Game",
                    "developers": ["Studio <b>One</b>"],
                    "publishers": ["Publisher"],
                    "release_date": {"date": "10. Jan. 2024"},
                    "genres": [{"description": "Action"}, {"description": "Adventure"}],
                    "short_description": "A <b>great</b> game.",
                    "website": "https://example.com",
                    "header_image": "https://cdn.cloudflare.steamstatic.com/steam/apps/570/header.jpg",
                },
            }
        }

    def test_parse_steam_metadata_normalizes_fields(self):
        metadata = parse_steam_appdetails("570", self.payload)
        self.assertEqual(metadata["metadata_title"], "Example Game")
        self.assertEqual(metadata["developer"], "Studio One")
        self.assertEqual(metadata["genres"], ["Action", "Adventure"])
        self.assertEqual(metadata["description"], "A great game.")
        self.assertTrue(metadata["header_image_url"].startswith("https://"))
        self.assertEqual(metadata["metadata_source"], "Steam Store")

    def test_parse_rejects_invalid_or_unavailable_app(self):
        with self.assertRaises(MetadataError):
            parse_steam_appdetails("abc", self.payload)
        with self.assertRaises(MetadataError):
            parse_steam_appdetails("999", self.payload)

    def test_unsafe_image_url_is_not_kept(self):
        payload = {"570": {"success": True, "data": {"name": "Example", "header_image": "http://evil.example/image.jpg"}}}
        self.assertEqual(parse_steam_appdetails("570", payload)["header_image_url"], "")

    def test_fetch_uses_validated_steam_response(self):
        response = FakeResponse(self.payload, b"{}")
        calls = []
        def fake_get(url, **kwargs):
            calls.append((url, kwargs))
            return response
        result = fetch_steam_metadata("570", http_get=fake_get)
        self.assertEqual(result["metadata_title"], "Example Game")
        self.assertEqual(calls[0][1]["params"]["cc"], "de")
        self.assertEqual(calls[0][1]["timeout"], (3, 6))

    def test_cover_download_is_bounded_and_cached(self):
        jpeg = b"\xff\xd8\xff" + b"sample-image-data"
        response = FakeResponse(content=jpeg, headers={"Content-Type": "image/jpeg", "Content-Length": str(len(jpeg))})
        with tempfile.TemporaryDirectory() as tmp:
            path = download_steam_cover("570", cache_dir=Path(tmp), http_get=lambda *_args, **_kwargs: response)
            self.assertTrue(Path(path).is_file())
            self.assertEqual(Path(path).read_bytes(), jpeg)
            self.assertEqual(Path(path).name, "steam_570.jpg")

    def test_cover_rejects_non_image_content(self):
        response = FakeResponse(content=b"not an image", headers={"Content-Type": "text/html"})
        with tempfile.TemporaryDirectory() as tmp:
            path = download_steam_cover("570", cache_dir=Path(tmp), http_get=lambda *_args, **_kwargs: response)
            self.assertEqual(path, "")


if __name__ == "__main__":
    unittest.main()
